film ten został zrealizowany w zamku belvedere w pradze , pałacu furstenberg w lobkowitz i w innych historycznych miejscach
" nie jestem bogiem , nie mogę być też diabłem , ale z lekceważeniem wymawiam imię twoje !
gdziekolwiek będziesz ty , tam i ja będę aż po twą ostatnią godzinę , po twój grób bedę na nim siedział ! "
studenci prascy żyją słodkim życiem !
" o co chodzi , baludinie ? "
" za najlepszego szarmierza w pradze i najbardziej wpływowego studenta ! "
scapinelli był popularny wśród studentów , z powodu braku skrupułów w postępowaniu
" jestem zrujnowany !
tak bym chciał zdobyć jakoś pieniądze albo bogatego spadkobiercę ! "
" wtedy pomyślałem , że najlepszy szarmierz w pradze i jeden z aktywniejszych studentów powinien otrzymać szansę ! "
zazdrosna lyduszka wie o starem oszustwie scarpinelliego i martwi się o balduina
przygotowania do polowania , na zamku hrabiego schwartzneberga
hrabina margit i jej kuzyn , baron waldis-schwartzenberg zgubili drogę
" margit , dlaczego wciąż odwlekamy nasze małżeństwo ?
wiesz , że pragnieniem twego ojca jest widzieć naszą rodzinę scaloną
" drogi kuzynie , będę posłuszna woli ojca , ale ja cię nie kocham "
" spójrz !
koń wiedzie nas ku jeziorze ! "
" przyjmij ten medalion z mą fotografią , jako prezent ode mnie "
" jestem panu dozgonnie wdzięczny , za uratowanie życia mojej córki "
dzień później
" jestem znany jako balduin , najlepszy szarmierz , ale moim prawdziwym wrogiem jest moje lustrzane odbicie "
balduin decyduje się odwiedzić hrabinę
" pozwolę sobie zapytać , jak się pani hrabina się czuje ? "
" panie balduinie , proszę pozwolić , że przedstawię panu barona walids-schwartzenberga przyszłego męża mojej córki "
balduin , który jest tylko biednym studentem , oddala się
" odszedłem za pozwoleniem ? ? ona , to bogata dziedziczka , a ja nikim więcej nie jestem niż biednym studentem "
" jak pan się tu dostał ? "
" drzwiami ! "
" zatem , panie studencie nie będzie pan jedynie najlepszym szarmierzem czy najdzikszym studentem , ale także "
" bogaczem ! ! "
" z jaką sumą ? "
gwarantuję , że otrzymam 100000 złotych monet , w zamian za to dam panu scarpinelliemu prawo do czegokolwiek w tym pokoju balduin
praga , 13 maja 1820 roku
" ależ z pana dziwak !
coś z tej rudery ? !
" proszę brać cokolwiek pan chce ! "
gwarantuję , że otrzymam 100000 złotych monet , w zamian za to dam panu scarpinelliemu prawo do czegokolwiek w tym pokoju balduin
praga , 13 maja 1820 roku
" może pan wybrać cokolwiek chce ! "
" panie studencie balduinie
chcę pańskiego odbicia z tego lustra
to jest mój sekret "
" co pan powiedziałeś ?
moje odbicie ? "
" w porządku umowa to umowa ! "
dla balduina rozpoczęło się nowe życie
" wyjeżdzam , gdyż zostałem zaproszony przez gubernatora "
" droga pani hrabino , czy mogę ? "
" nareszcie los pozwolił nam być sam na sam przez chwilę "
" margit kocham panią ! "
" a ja nie potrafię "
lyduszka podąża za parą
" do widzenia , panie balduinie "
" czyż to jawa czy sen ?
kim jesteś ?
" czy masz jakieś problemy , mój przyjacielu ?
zbladłeś , nie czujesz się dobrze ? "
" zobacz spójrz na swe odbicie w lustrze "
" moja droga kuzynko , nie zapominaj , że jesteś moją narzeczoną "
balduin czeka na powóz hrabiostwa
hrabianka , w swoim pokoju
" tak , panie balduinie , moje serce do pana należy ! "
droga hrabianko , proszę dotrzymać swego przyrzeczenia i zobaczyć się ze mną jutro o 11 wieczorem , w tym samym miejscu co zwykle
lyduszka szuka hrabianki
hrabianka margit zmierza na spotkanie
" proszę zaczekać !
jeśli pójdzie pani na to spotkanie , będzie pani w poważnym niebezpieczeństwie ! "
" czego chce ta cyganka ode mnie ? "
margit stara się być dzielna , podczas drogi do " świętego źródła "
margit przywołując słowa cyganki , przeżegnuje się
" dlaczego wybrał pan to miejsce ? "
" moja droga hrabianko , z powodu ciszy , spokoju , osamotnienia "
" kim pan jest ? "
" panie baronie sądzę , że panna hrabianka zgubiła swą chusteczkę "
" ma pan czelność wątpić w mego narzeczeństwa wierność ? "
balduin , wciąż oszołomiony tym co zaszło , wraca do domu
" dlaczego pan tu przybył , panie baronie ? "
" nie zamierzam o tym dyskutować
pan plami honor mojej familii jestem do pana dyspozycji "
ojciec chrzestny balduina rozmawia z baronem i organizuje pojedynek
" panie baronie , wybiera pan szablę czy pistolet ? "
" co takiego ?
szablę ?
przecież balduin to najlepszy szarmierz w pradze ! "
" dlaczego jest pan tu jest , panie hrabio ? "
" proszę dać mi słowo , że nie zabije pan pana barona
to jedyny syn mej siostry , mąż przyszły mojej córki , mój spadkobierca i ostatni , który nosi naszej familii nazwisko "
" ma pan , panie hrabio , moje słowo "
balduin zmierza na pojedynek
" dokąd pan idzie ? "
obietnica złożona hrabiemu została złamana przez jego drugie ja
balduin stara się wytłumaczyć śmierć barona
" rodzina pana barona nie ma nic panu do powiedzenia , panie balduin ! "
balduin stara się zapomnieć o swej ukochanej
" pragnę twej miłości , a nie twoich pieniędzy ! "
" chciałby pan zagrać ze mną w karty ? "
" jaka jest stawka ? "
" jeden z nas ! "
a gdziekolwiek odpocznę , gdziekolwiek umrę , tam zawsze ktoś za mną podążać będzie jak brat - dziwny , ubrany na czarno człowiek
" muszę się z nią znów zobaczyć !
muszę z nią porozmawiać i wszystko wyjaśnić "
" pani hrabianko , to nie była moja wina ! "
proszę mnie nie nienawidzieć ! "
" balduinie , gdzie pańskie odbicie ? "
" możesz pan mówić , co chcesz , ale kto do prześladowania mnie dał panu prawo ? "
" nie jestem bogiem , nie mogę być też diabłem , ale z lekceważeniem wymawiam imię twoje !
ponieważ gdziekolwiek będziesz ty , tam i ja będę
balduin rzucił się do ucieczki , a diabeł podążył za nim
" on wciąż mnie śledzi ! "
" scapinelli , zabieraj pan z powrotem swoje pieniądze ! "
" wciąż czuję jego obecność ! "
" pozbędę się ciebie , raz na zawsze
zabiję cię moim pistoletem ! "
" jestem bezpieczny ! "
" krew jestem ranny ! "
gwarantuję , że otrzymam 100000 złotych monet , w zamian za to dam panu scarpinelliemu prawo do czegokolwiek w tym pokoju balduin
praga , 13 maja 1820 roku
" nie jestem bogiem , nie mogę być też diabłem , ale z lekceważeniem wymawiam imię twoje !
gdziekolwiek będziesz ty , tam i ja będę aż po twą ostatnią godzinę , po twój grób bedę na nim siedział ! "
tu spoczywa balduin >> napisy pobrane z http : //napisyorg << >>>>>>>> nowa wizja napisów <<<<<<<<
wierne serce
maria była dzieckiem-znajdą
przybrani rodzice surowo ją wychowywali
bardziej niż od ciężkiej i znojnej pracy , maria cierpiała od pożądania mężczyzny , który napawał ją lękiem
cała okolica obawiała się pawła petit , miał bardzo złą opinię
ale każdego popołudnia prawdziwa miłość podtrzymywała marię na duchu
a ty dokąd z tą butelką ?
idę poszukać oleju
a całkiem spokojny paweł petit niczego się nie domyślał
boję się
ojciec i matka chcą , żebym wyszła za pawła
muszę wyjechać
zabieram dziewczynę
weźmiemy ślub w wiosce , mieszka tam moja siostra
mam do pana kilka słow !
wiem , że maria nie jest pana córką
to jean , facet , który przychodzi do niej w konkury
mówią , że on i maria mają się ku sobie
kochamy się
weźmiemy ślub
na zawsze
pięknie się odwdzięczasz , niewdzięcznico !
zbierz swoje rzeczy , odejdziesz z pawłem petit
jan na próżno czekał w stałym miejscu spotkań
czy jest maria , kelnerka z tej gospody ?
odeszła odeszła
pojedziemy do ślubu na konikach z karuzeli
odeszła z pawłem petit
paweł petit uciekł organom ścigania
jean został uznany za winnego , odsiedział rok w więzieniu
wierne serce
i po południu też nic
wreszcie pewnego ranka
przez wzgląd na dziecko , nie odważył się podejść do niej
ale nadal szedł za nią
czy to jej dziecko ?
z kim teraz żyje ?
z pawłem petit , ale jest bardzo nieszczęśliwa
nie mam pieniędzy
szybciej , szybciej , odejdź !
odejź !
odejdź ! jeśli cię tu znajdzie , zabije nas wszystkich !
zawsze jest pijany !
uważajcie !
paweł petit idzie !
jest pijany
musisz wyjść !
nie chcę awantury !
możesz pójść do niej !
ale plotki rozchodzą się szybko
patrz na nią
plotki
mam dla ciebie ciekawą wiadomość , będziesz zaskoczony
właśnie dowiedziałam się , że
widzieli jana w domu z twoją żoną
jana widzieli z tobą
jeśli go tu złapię , to z tobą i znim się policzę !
rusz się ! dawaj zupę !
nie miałam czasu gotować
całe przedpołudnie byłam z dzieckiem w szpitalu
pójdę zjeść gdzie indziej
gdy pawła petit nie było w domu , kaleka dziewczyna rysowała znak w umówionym miejscu
również w tym samym czasie , gdy maria opiekowała się dzieckiem , mając nadzieję na jego wyzdrowienie
paweł petit , ze swej strony
jean spotkał się z twoją żoną
jest teraz w domu
jan jest z marią
rysuje nawet sekretne znaki miłosne na murach
wyjedźmy stąd
miłość pozwala zapomnieć o wszystkim
na zawsze
tłumaczenie : zdrowa_woda@pocztafm
złoto alaski ! marzenie buńczucznych mężczyzn bezlitosna syrena północy wabiła ich tysiące do swej
lodowej , dziewiczej krainy
przełom chilkoot odgradzał pola złota od kraju nędzy i głodu
wielu zginęło tam z wycieńczenia , inni zawracali z drogi , dzielni kontynuowali
po tym dalekim , lodowym pustkowiu maszerował nieustraszony poszukiwacz
wśród tego pustkowia znajdował się inny poszukiwacz
z optymizmem nasz mały kolumb posuwał się naprzód zatrzymał się , ruszył , poślizgnął i wstał
" zanim dowiem się " , pomyślał mały
" gdzie jestem , pójdę tam "
gdzieś wśród lodów marzenie spełniło się i głos wzniósł się ku niebu :
" eureka !
znalazłem górę złota ! "
lecz żywioły zakpiły , zaryczały i zagrzmiały
na pustkowiu stała chata , a w niej inny samotnik : black larson , chciwy i drapieżny rabuś
prosto z burzy śnieżnej wszedł do biednej chaty mały , by znaleźć w niej schronienie i trochę gościnności
usiadł , by dać odpocząć kościom mroźny wiatr wył pomiędzy deskami
" podejdź tu ! " nakazał larson
" co robisz ? "
" jem jak widzisz "
" wynoś się ! "
" no idź ! "
" wyłaź ! "
big jim też siłował się z wiatrem
szlachetny big jim cierpiał wiele
uwielbiał cierpieć i cierpiał z każdego powodu
" wynoście się ! "
" bo przepędzę was kulami ! "
" obydwaj !
" już ! "
tego rodzaju hałasu jim nie tolerował
" zostaję tu , zrozumiano ? "
" tu właśnie ! " powiedział big jim
" tak , proszę pana , on zostaje tu " powiedział mały
" zrozumiano ?
my zostajemy tu "
i zostali dnie i noce w wynędzniałej chacie
chodzili tak w milczeniu , a głód skręcał im kiszki
" muszę coś zjeść ! " zawył big jim
" jeść ! "
" co jesz ? "
" nic "
" otwórz usta ! "
" kłamiesz , jesz świecę "
" świecę ?
oburzające ! "
" gdybym wiedział , że kłamiesz , rozkroiłbym ci gardło ! "
" jeden z nas musi stawić czoło wichurze , by zdobyć żywność "
" chodźcie tu ! "
" pójdzie ten , kto wyciągnie słabszą kartę "
" idziesz ty "
" powodzenia ! "
" i nie zapomnij o bekonie "
gdzieś wśród pustkowia , prawo ścigało larsona
święto dziękczynienia zastało ich w głodowej rozpaczy
jednak było coś , za co mogli dziękować
" będzie gotowe za dwie minuty "
" dawaj , dawaj "
przebywszy cały kraj , mały nie znalazł do jedzenia nic , nawet polnej myszy
głodowe męczarnie doprowadzały jim'a do szaleństwa
stawał się uciążliwy
" jeść ! jeść ! " grzmiał
" ugotować drugi but ? "
" tylko nie to ! "
biedny jim nie mógł tego znieść
" co ci jest ? "
" wziąłem cię za kurczaka "
" zapal ogień ! "
" co ci jest znowu ? "
" chodź tu , ptaszku ! "
" tylko bez kaprysów ! "
" przestań
oszalałeś , to ja ! "
" to ty ! "
" wybacz , chyba oszalałem "
" zauważyłem właśnie "
" wchodź do środka , ja biorę strzelbę "
kurczak czy nie , mały wyglądał jednak apetycznie
w tym czasie , larson natknął się na złoto jim'a
przyszedł czas ruszyć w drogę
jim po swe złoto , mały w stronę przeznaczenia
" żegnaj "
" miło mi było cię poznać "
zdrajca czekał w ukryciu na jim'a
jim spojrzał w oczy black larson'owi wyzierała z nich dusza łotra
ofiara własnej chciwości ,
larson został ukarany przez los
wznosząca się osada ogrzewała lodową pustynię
ludzkim życiem , miłością i żądzami
georgia
jack-uwodziciel
georgia-impulsywna , dumna i niezależna
wieczorami pracowała tańcząc na dansingu
jim zalecał się do niej ,
lecz ona go odpychała
przyszedł raz na dansing mały wszedł na salę taneczną - ostoję rozkoszy i zatraconych marzeń
" czemu nie jesteś miła dla jack'a ? "
" podobasz mu się bardzo "
" wszystkie mu się podobają "
" mam dosyć tej pracy "
" porzuciłabym to wszystko dla kogoś uczciwego "
" kiedyś na pewno go znajdę "
po czym odwróciła się i patrzała , patrzała i patrzała
" zarozumiała " pomyślał jack
" złaź z piedestału "
" teraz tańczysz ze mną "
" grajcie do tańca "
" powiedziałem , tańczymy ! "
" co proszę ? "
by okazać mu swą pogardę , wybrała do tańca najnędzniejszego trampa
" hej , ty !
" tak , ty
chcesz zatańczyć ? "
" nie tańczę z byle kim "
i stanął , jak dzielny rycerz , broniąc jej sanktuarium
" jeśli chcesz uwieść ją , "
" popraw się i włóż porządnie kapelusz "
" a masz ! "
" dobrze mu tak "
" nie znałem własnych sił ! "
chata hank'a stała nie opodal dansingu
hank , inżynier kopalni , żył samotnie czasami wyruszał na daleką północ
hank był dobry i ludzki , mały , głodny i zmarznięty , fasola smaczna a kawa gorąca
mały znalazł sposób , by wprosić się na śniadanie
big jim ocknął się z krwawych ran , lecz stracił pamięć
przyjeżdża partner hank'a
razem wyruszają na daleką wyprawę
hank informuje go , że mały będzie w tym czasie strzegł chaty
" do widzenia
nie zapomnij karmić muła "
mały nie spotkał georgii od nocy na dansingu , lecz los znów skrzyżował ich drogi
jej czar promieniował na całą izbę , wypełniając jego serce po brzegi - uczucie dotąd mu nieznane
gdy go przedstawiła , jego serce zaczęło śpiewać
przeprosił je , by pójść po drzewo
jego sekret został odkryty : kochał się w georgii
dziewczęta śmiały się , by ukryć wzgardę
w świecie tancerek niebezpiecznym było wyjawiać swe uczucia
postanowiły pożartować sobie z niego
zasiadły z boku , z twarzami pełnymi zawiści , lecz jego serce wciąż śpiewało
ona flirtowała , głaskała go po głowie
nie będąc naiwnym , był szczęśliwy : była przy nim , trzymała go za rękę , uśmiechała się do niego
" przyjemne miejsce "
" zaprosisz nas chyba jeszcze "
czy żartowała ?
rozkoszował się ciepłem jej oczu , zaś jej koleżanka ciepłem krzesła
zbierała się do wyjścia
jej piękno odchodziło , a on odnajdywał na nowo pustkę swej smutnej , samotnej egzystencji
" przepraszam " " ale czy naprawdę , ” brakowało mu słów ,
" chciałbyś tu wrócić ? "
" oczywiście
co wy na to ? "
" przyjdziemy na noworoczną kolację "
" bardzo dobrze "
" przyjdziemy tu na sylwestra "
akurat georgia zapomniała o swych rękawiczkach
przez następne dni ciężko pracował , by móc przygotować sylwestra
nowy rok !
nowe nadzieje i marzenia
georgia uśmiechała się do niego czule
poprosiły go o przemowę
ze szczęścia oniemiał
liczyła się tylko georgia
była tu z nim !
jąkając się wreszcie powiedział :
" zamiast przemawiać , zatańczę "
i przedstawił taniec bułkami
w połowie hucznej zabawy georgia przypomniała sobie o obietnicy
" chodźmy odwiedzić małego "
" spłatamy mu figla "
" idź pierwsza , a my go przestraszymy "
" nie myśl o tym
zajmij się lepiej mną "
jim w biurze rejestracyjnym zapewniał urzędników , iż znalazł górę złota
" w którym miejscu ? "
lecz pamięć go zawiodła
wiedział tylko , że było to obok chaty
" chata ! "
" gdybym tylko mógł odnaleźć chatę , odnalazłbym złoto "
" ale nie pamiętam ! "
" twoja przyjaciółka georgia szuka cię "
mały brał to za kpiny
" jak ten gbur śmie o niej mówić tak lekceważąco ! "
dałby mu nauczkę po raz wtóry , ale będąc nieco wątłym , wolał zignorować żarty
lecz georgia naprawdę go szukała
zostawiła mu list /wybacz mi , /że nie przyszłam na kolację , /chciałabym cię zobaczyć /i wytłumaczyć
podczas gdy on szukał jej , big jim szukał jego
" ty ! to ty ! " powiedział big jim
" ciebie właśnie szukałem ! "
" chata !
gdzie jest chata ? "
" odpowiedz mi ! "
" odpowiedz wreszcie ! "
" gdzie jest chata ?
gdzie ona jest ? "
" nareszcie odnajdę moje złoto "
" szybko , na nogi ! "
" idziesz ze mną ! "
" zabierz mnie do chaty , a uczynię cię milionerem ! "
" georgia , chwileczkę " powiedział mały
" georgia , nic nie tłumacz , ja rozumiem "
" kocham cię i zabiorę cię stąd ! "
" odjeżdżam , ale wrócę , kiedy wrócę "
wyczerpani dotarli do chaty
" to długo nie potrwa "
" wnieś żywność zaczniemy kopać jutro "
" napij się łyka , to cię ogrzeje "
" ciężki jest ten barani udziec "
los znów spłatał im figla i żywioły znów zakpiły , zaryczały i zagrzmiały , lecz nic nie zbudziło naszych bohaterów
nadszedł ranek
mały obudził się nieświadom nocnych wydarzeń , za to świadom " wydarzeń " poprzedniego wieczoru
" przygotuję coś na śniadanie " pomyślał mały
" nigdy nie miałem takiego ataku wątroby "
" czujesz to kołysanie ? "
" to żołądek "
" to nie żołądek "
" chodźmy tam
zobaczymy , o ile się przechyli "
" brakuje czegoś pod spodem "
" sprawdzę , co to jest "
" tylko bez paniki "
" uspokój się , nie ruszaj się i nie oddychaj "
" powiedziałem , nie oddychaj , głupcze "
" czasami jesteś naprawdę denerwujący "
" bądź spokojny " powiedział jim
" nie mamy o co się martwić "
" wykaż nieco siły charakteru "
" słuchaj mnie " " mam pomysł "
" wyciągnij ramiona , to ja wyjdę "
" rozumiesz o co mi chodzi ? "
" masz zupełny chaos w głowie "
" kompletny brak kontroli "
i big jim odnalazł swój skarb
" teraz będziemy bogaci ! "
" będziemy milionerami ! "
i nimi zostali
wracali teraz do domu , opuszczając nieprzychylną alaskę , by żyć w kraju dostatnim i rozkoszować się największym luksusem
byli sławni i pisano o nich w prasie
witano ich i obsługiwano w luksusowych kabinach
reporter chciał spisać historię małego
" od łachmanów po miliony "
jim'owi robiono manikiur
" nie paznokcie , tylko zrogowacenia "
reporter wpadł na pomysł , by mały pozował w starym ubraniu , by nadać jego historii " ludzkości "
georgia !
podróżowała trzecią klasą , niczego nieświadoma
usłyszała , że oficer poszukuje pasażera na gapę
" to ty ! "
" myślałam , że cię już nigdy nie zobaczę "
wzięła go za poszukiwanego
oficer miał zakłuć go w kajdany , gdy georgia zaproponowała zapłacić za niego
" to nie pasażer na gapę "
" to wspólnik big jim'a , multimilioner "
nastąpiły oczywiście przeprosiny
mały poprawił się , a lokaj przygotował miejsce dla gościa
" przepraszam , kim jest ta pani ? "
" psst , psst , psst "
" naprawdę ?
moje gratulacje "
" to będzie historia ze szczęśliwym końcem "
i rzeczywiście , był to szczęśliwy koniec
adaptacja : anna bielecka
napisy :
przez dziesiątki lat " zaginiony świat " mógł być oglądany tylko w skróconej godzinnej wersji
ta edycja łączy w sobie części z ośmiu dostępnych wydań , ukazując rekonstrukcję najbardziej kompletną z możliwych
zdumiewająca historia przygody i romansu sir arthura conan doyle'a
zaginiony świat
adaptacja : watterson r rothacker
wstęp sir arthura conan doyle'a , autora powieści
napisałem sobie prosty plan : -dać godzinę radości chłopcu , który jest na wpół mężczyzną , albo mężczyźnie , który jest na wpół chłopcem
londyn
mam przeczucie , że chcesz mi coś zaproponować , ed
chciałabym , żebyś tego nie robił jest miło tak jak jest
ale dlaczego nie możesz mnie pokochać , gladys ?
powiedz , co jest ze mną nie tak
poślubię tylko człowieka wielkich czynów i osobliwych przeżyć
- człowiek , który zdoła spojrzeć śmierci w twarz i nie cofnie się !
w biurze /london-record journal
chciałbym zasięgnąć twojej porady prawnej
profesor challenger grozi , że zaskarży moją gazetę za zwątpienie w jego historię o żywych dinozaurach
sławni zoologowie wracają z ameryki południowej bez dowodów na poparcie dziwnej opowieści
profesor challenger , znany autor i naukowiec powrócił do londynu z dziwną opowieścią o mamutach , pterodaktylach i innych prehistorycznych potworach wędrujących swobodnie gdzieś u źródeł amazonki
niestety , nadwyrężając swoją reputację co do prawdomówności , odmawia wskazania dokładnego położenia swojego odkrycia , a jego fotografie niefortunnie uległy uszkodzeniu , (w czasie , gdy jego kajak , jak mówił , wywrócił się) tak , że nie mogą stanowić dowodu w tej sprawie
challenger jest obłąkany !
prawie zabił trzech reporterów , których wysłałem dzisiaj , by zrobili z nim wywiad !
panie mcardle , czy nie mógłby pan dać mi jakiś niebezpieczny przydział ?
potrzebuję okazji -
pan chyba bardzo chce stracić życie !
robił pan już wywiad z challengerem , malone ?
proszę nie przepraszać - tylko pędem do sali zoologicznej na wykład challengera
reporterzy nie mają wstępu - ale musi pan tam wejść !
to jest sir john roxton - sławny myśliwy i odkrywca
jest tu , by sprawdzić absurdalną historię challengera
cóż , malone , będziemy tu mieć występ na żywo - studenci nie będą nękać pytaniami starego challengera
challenger publicznie się ośmieszył - tą swoją opowieścią o żywych dinozaurach !
co chciał osiągnąć przez te kłamstwa ?
dorzecze amazonki ma ponad 50 tys mil nieodkrytych dróg wodnych
kto to może wiedzieć , co żyje w tej dżungli - ogromnej jak cała europa ?
ale jak historia challengera może być prawdziwa ?
te stworzenia wyginęły przed milionami lat !
przynajmniej może mu pan oddać sprawiedliwość i wysłuchać jego wystąpienia
reporterzy nie maja wstępu- jeśli pokażę swoją legitymację wyrzucą mnie zastanawiam się , czy pan -
chętnie - wprowadzę pana na moją wejściówkę
to profesor summerlee , znakomity znawca owadów
- z uwagi na brak dowodów , nasze towarzystwo nie może sponsorować oświadczenia profesora challengera , ale z chęcią da mu okazję wyjaśnienia jego przypadku , i , jak mniemamy , oczyszczenia własnego imienia
daj nam swoje mastodonty !
przyprowadź swoje mamuty !
przyprowadzę - jeśli któryś z was , bezkręgowców będzie miał dość odwagi by wrócić ze mną do bezkresnej dżungli gdzie te potwory żyją !
mówiłem panu , stary challenger jest szczery !
i nie stoję tu dziś przed wami by bronić mych twierdzeń - ale by domagać się zwołania komisji , która wróci ze mną do zaginionego świata-
co za godne pożałowania zamieszanie !
bezcelowe jest apelować do nierozwiniętych umysłów !
wzywam ochotników !
ochotników gotowych stanąć twarzą w twarz ze śmiercią - lub gorzej - z nauką
mam 67 lat - ale , ponieważ myślę , że jest pan kłamcą i oszustem - przyjmuję pana wyzwanie , sir !
przyjęty !
lepszy stary głupiec - niż młody tchórz !
nie jestem ani studentem ani naukowcem - ale proszę mnie również ująć !
mój przyjaciel , sir john roxton !
przyjęty !
pańska sława wielkiego myśliwego doda wagi pańskim zeznaniom - jeśli wrócimy !
profesorze challenger , chciałbym wyruszyć z pańską wyprawą !
prawdopodobnie mózg dziecka - ale ciało atlety
przyjęty
jak się pan nazywa ?
edward e malone -
a czym się pan zajmuje ?
ja jestem re reporterem , sir /london-record journal
zawieź mnie do domu - mam tego dość !
enmore park 11 , kensington , west !
profesorze challenger , muszę wyruszyć na tę wyprawę !
dziewczyna , w której się kocham nie wyjdzie za mnie dopóki nie stawię czoła śmierci , albo
ten człowiek mnie zaatakował !
czy wniesie pan oskarżenie ?
nie to moja wina
to ja mu się narzucałem
czy teraz moglibyśmy rozsądnie porozmawiać o ekspedycji ?
sir john roxton jest moim przyjacielem-
dlaczego wcześniej pan o tym nie wspomniał ?
znowu zraniłeś miłego , młodego człowieka !
widziałam cię z okna jadalni !
jeśli mój mąż znów pana obrazi- proszę mnie tylko zawołać !
podczas rozmowy z policjantem błysnął pan inteligencją-
niech pan siada !
chce się pan przyłączyć do wyprawy bo wierzy pan w moją historię ?
austin !
powiedz pannie white , że chciałbym ją zaraz widzieć !
pokazałeś już malone'owi dziennik ?
własność maple'a white'a ?
brontosaurus
panna paula white - córka biednego maple'a white- nieszczęsnego odkrywcy , którego notatnik trzyma pan w ręku
panna white była jego asystentką
powie panu , dlaczego przyszła do mnie
byłam wtedy w obozie i miałam malarię , gdy mój ojciec odkrył ten okropny płaskowyż
mięsożerne zwierzę , allosaurus
właśnie widziałem kilka z nich na polanie
żywy brontosaurus
to znaczy , że widziała pani żywych potomków tych potworów które przypuszczalnie wyginęły przed milionami lat ?
tak , były olbrzymie i dzikie
nasi tragarze byli tak przerażeni , że opuścili nas- zabrali mnie z powrotem na wybrzeże - i zostawili ojca tam w górze - razem z tymi bestiami -
on poszedłby - wbrew temu , co widzieliśmy
mój mąż obiecał zebrać fundusze na przyjęciu dobroczynnym- ale zamiast uzyskać pomoc od ludzi , wyrzucał ich przez okno !
dlaczego , to wielka ludzka , interesująca historia -
i nawet jeśli moja gazeta nie ma dla pana naukowej wartości- to mogłaby sfinansować przyjęcie dobroczynne przy zapewnieniu prawa na wyłączność publikacji-
przyrzekam nie wysyłać artykułu do mojej gazety bez pańskiej pełnej aprobaty !
jeśli sir john roxton pojedzie ze mną - wierzę , że przekonamy mojego wydawcę !
jestem pewny , że wie pani , paulo , dlaczego organizuję to przyjęcie dobroczynne
liverpool
rzeka amazonka
nie będę zanudzał swoją opowieścią tych , do których trafi ta relacja z naszej ekspedycji
w końcu znaleźliśmy się na tej ziemi niczyjej , położonej gdzieś na granicy między peru , brazylią i kolumbią
zapieczętowana mapa , której , dając słowo challengerowi , zobowiązaliśmy się nie otwierać dopóki nie dotrzemy do celu okazała się czystą kartką
tylko cud mógł uratować naszą wyprawę przed jej przedwczesnym końcem
mogę wejść ?
od tej chwili przejmuję dowodzenie nad tą wyprawą
postawmy sprawę jasno , beze mnie wszyscy jesteście tu bezradni !
jeśli tamto psotne zwierzę idzie z nami , zostaję z tyłu !
jocko potrafi rozpoznać , które jagody i korzenie w lesie są jadalne , a które trujące - on będzie dla nas o wiele bardziej użyteczny niż pan , drogi panie !
zapis
odkrywcy docierają do ostatniej placówki cywilizacji
record-journal , towarzystwo poszukiwawcze zaginionego naukowca przecierające szlak przez tajemniczy świat i nieznane rzeki ,
nie wysłało żadnej wiadomości od miesięcy
to brazylijski leniwiec - one zawsze chodzą z głowę w dół
widzicie dziecko przyczepione do niej ?
drogi panie mcardle :
to już trzy tygodnie jak odesłaliśmy nasze canoe a dzisiaj biwakujemy u podnóża wielkiego płaskowyżu , na którym pozostał maple white
challenger doprowadził nas do tego miejsca , i udowodnił istnienie płaskowyżu - ale nie mamy żadnego powodu by wierzyć , że jakieś potwory wędrują po nim gdzieś tam w górze
to nie sa młode - ale zupełnie dorosłe " fenomenalne misie " - wielcy obozowi zwolennicy
paula powiedziała , że jej ojciec zrąbał jedno z drzew na tamtej iglicy tak , że upadło w rozpadlinę i utworzyło most
wciąż można zobaczyć pień tego starego drzewa
rano wejdziemy na szczyt - i zetniemy drugie drzewo
pterodaktyl - wyraźnie udowadnia , że zapiski w dzienniku biednego maple'a white były prawdziwe !
brontosaurus - żywi się jedynie liśćmi
całkowicie nieszkodliwy - chyba , że na nas nadepnie
kto by temu uwierzył !
moja strzelba na słonie jest tu dziecinną pukawką na fasolę !
wielkie nieba !
nie możemy wrócić !
jesteśmy uwięzieni - dokładnie jak maple white !
to oznacza , że nasi ludzie wciąż żyją !
o czym myślisz , paula - w tym naszym zaginionym świecie ?
myślałam , że gdyby mój ojciec wciąż żył - zobaczyłby nasz ogień
- i przyszedłby tu
allosaurus - mięsożerca- najbardziej występny szkodnik pradawnego świata
ogrodzenie równie dobrze mogłoby być z ostowego puchu - i następnym razem ogień może nie zadziałać
- musimy znaleźć bezpieczny obóz !
jocko będzie tu bardzo samotny bez panny pauli - rankiem wejdzie na tą ogromną skałę by się do niej dostać - nie może wytrzymać , gdy straci ją z pola widzenia !
mam pomysł !
po kolacji przynieśmy wszystkie hamaki do namiotu !
założymy obóz tutaj- to jedyne schronienie przed tymi potworami - jeśli pożyjemy dostatecznie długo , by odszukać pani ojca
teraz , gdy odkryliśmy te jaskinie , moglibyśmy tu żyć do końca naszych dni - gdybyśmy tylko mieli jakąś broń zdolną naruszyć skórę dinozaura !
zaraz wynajdę taką broń
nie spoczniemy , dopóki nie zbadamy każdy cala tego płaskowyżu !
on się ciągnie milami - pani ojciec mógł odkryć inne jaskinie -
kiedy puszczę to drzewo , trzaśnie z przerażającą siłą - obliczyłem krzywą jaką kreśli skała gdy wyrzuca je w powietrze-
krzywa ?
nonsens !
każdy uczeń w szkole panu powie , że skała zakreśla parabolę
krzywą !
parabolę !
miałem rację - pan zakreślił krzywą !
będziemy pracować przez noc , zbudujemy drabinę i rankiem pana wydostaniemy
świetnie !
ale jak do pioruna chcecie ją nam tu podstawić ?
niech panna paula zawoła jocko - on wciągnie tam wszystko , byleby się do niej dostać !
tam wyżej jest tylko mała jaskinia - ale pani ojciec musi gdzieś być na tym płaskowyżu - stąd się nie można wydostać !
to znaczy , że myślisz , że zostaniemy tu na zawsze ?
co różnica gdzie jesteśmy , paula - jeśli jesteśmy razem ?
a co z twoją obietnicą złożoną gladys ?
paulo , najdroższa , jesteśmy odcięci od świata i wszelkie zobowiązania i obietnice nie mają tu żadnej mocy
poproszę profesora summerlee by udzielił nam ślubu
wie pan , on był ministrem
niech pan idzie upolować profesorów - chciałbym coś powiedzieć pauli
śliczny okaz !
podejdziemy i będziemy obserwować ich zwyczaje !
ten uśpiony wulkan budzi się !
cały płaskowyż pokryje lawa !
ale to kwestia godzin - obawiam się , że są zgubieni -
jeśli zdołaliby wrócić , musimy tu być by wskazać im drogę przez tunel
to ich jedyna szansa na ucieczkę !
profesorowie i pan malone są bezpieczni - będą tu za minutę !
mam nadzieję , że to błoto go utrzyma !
wracamy do świata - i zobowiązań
dlaczego mamy pozwolić gladys ograbić nas z naszego szczęścia , paula ?
nie mogę skraść szczęścia innej kobiecie
jestem major hibbard , z brazylijskiego nadzoru geodezyjnego
wczoraj spostrzegłem nad płaskowyżem chmurę dymu -
i wykurzyliśmy niezłego szczura , majorze !
wyłożyłbym cały osobisty majątek , by doprowadzić tą bestię do londynu - żywą !
poślę po ludzi do pogłębienia tego źródła - zbudujemy stalową klatkę i tratwę - i gdy w następnym miesiącu nastanie pora deszczowa , moglibyśmy spławić pańskiego " szczura " !
jeśli naszą tratwą dopłyniemy do amazonki , moglibyście wynająć tam parowiec !
później - w londynie
dzisiejszego wieczoru nie będziecie drwić - ponieważ przywiozłem żywy dowód moich twierdzeń !
mogę zapytać , profesorze , co ma pan na myśli mówiąc " dowód " ?
żywy brontosaurus - prawie 60-stopowy od nosa do końca ogona !
pan edward malone , który przyczynił się finansowo do tej wyprawy właśnie w tej chwili nadzoruje rozładunek potwora ze statku , który wynajęliśmy-
wiadomość , której oczekiwałem , nadeszła !
za chwilę poinformuję państwa gdzie i kiedy będzie można oglądać brontosaurusa !
kiedy w doku mocowaliśmy klatkę , pękła lina-
nachylenie spowodowało zmiażdżenie klatki - i straciliśmy ją !
wybuchła panika - na ulicach są zamieszki !
mój brontosaurus uciekł !
oczyśćcie ulice , póki go nie odzyskam !
to zniewaga - znowu nas nabrano -
challenger powinien uciec z miasta !
jak się masz , gladys
jak widzisz - wróciłem
i skoro naprawdę to wszystko zawdzięczasz mnie , mam nadzieję , że mi wybaczysz - że nie czekałam
mój mąż , percy potts
mogę zapytać jakiej to wielkiej sztuki , jakiego bohaterskiego czynu dokonał pan potts - by cię zdobyć , gladys ?
to był tylko taki mój dziewczęcy kaprys !
percy jest sprzedawcą w domu towarowym , i nigdy w życiu nie był poza londynem !
przepraszam !
ona na mnie nie czekała - wyszła za mąż !
to sir jan roxton - myśliwy
każda epoka marzy o następnej
- jules michelet
obecnie jako naród , dotkniemy niebios !
z przyjemnością ogłaszam koniec ludzkiej historii osiągnięć naukowych !
nasza potęga będzie promieniować w całym wszechświecie !
byście żyli wiecznie !
nasz ziggurat !
roboty są ostatnio takie bezczelne !
to oburzające !
przyszłość gospodarki zależy od robotów
problemem są niesnaski pomiędzy robotami a ludźmi
słyszałem , że nasi wrogowie mają nową broń
dlatego metropolis potrzebuje silnego , charyzmatycznego przywódcy !
gratuluję z powodu ziggurat zajmiesz się teraz polityką ?
o czym ty mówisz !
o ile prezydent boon będzie zdrów , by rządzić naród jest bezpieczny
nie mam nic więcej do roboty
czy książę red zajmie się polityką ?
nie wypytuj go tak
nie wygram z księciem redem , jeśli chodzi o popularność
chodzą pogłoski , że ziggurat jest obiektem wojskowym
usłyszymy coś o tym od burmistrza ?
spytaj skunksa , ministra stanu !
hura ziggurat !
hura metropolis !
wujku , co to jest " ziggurat " ?
nie jestem pewien
patrz !
co to ? !
marduk
znak marduka
hej ! jest tam !
dr laughton , ma być gotowe dziś wieczorem !
cóż , dostarczyłem pieniądze i pomieszczenia tak jak chciałeś !
daj mi trochę czasu
już prawie skończyłem
dość mam tych wymówek !
jutro to obejrzę
nie warto tam iść
straszny tam bałagan
do jutra !
to rock
było zamieszanie na placu
tak , robot był poza obszarem
bez wymówek zarządzasz bezpieczeństwem
tak , ojcze
ty idioto !
nie jestem twoim ojcem !
przygarnąłem cię po wojnie , byłeś sierotą ! - zbyt wiele zakładasz !
- tak jest
shunsaku ban , prywatny detektyw z japonii
gdzie jest inspektor notarlin ? mam list od komisarza policji
rozumiem
więc ten dr laughton ukrywa się w metropolis ? to chciałeś powiedzieć ?
właśnie
powiedział mi przemytnik organów , który z nim robi interesy
międzynarodowa obrona praw człowieka aresztowała ludzi za używanie zwierząt w doświadczeniach i handlowanie organami
potrzebuję twej współpracy jestem tu po raz pierwszy , i nie mam pojęcia co jest co
chciałbym ci pomóc , ale świętowanie na cześć zigguratu będzie trwało jeszcze tydzień jesteśmy przez to bardzo zajęci a i tak brakuje nam ludzi
nie mam nikogo , kto mógłby ci pomóc
nie mam ludzi , ale jeśli zgodziłbyś się na robota ?
robot ? !
tak , robot
wspaniały robot
nie ma prawa aresztować ludzi , ale może prowadzić śledztwo , więc myślę , że ci się przyda
chyba nie muszę go zwrócić z pełnym bakiem , co ?
nie , tankuje się go raz na 5 lat
wkrótce ludzie nie będą potrzebni
kenichi
miło mi
jestem modelem 803-d , rp , dm , 497-3c
- miło cię poznać
wkrótce , gdy ukończymy ziggurat będziemy wiedli w przemyśle i kulturze
od tego dnia można uznać , że będą to narodziny tysiąc-letniego narodu
z przyjemnością ogłaszam koniec ludzkiej historii osiągnięć naukowych !
nasza potęga będzie promieniować w całym wszechświecie !
byście żyli wiecznie !
nasz ziggurat !
od czego zaczynamy ? 803
d , rp , dm , 497-3c
nie masz łatwiejszego imienia ?
nie nadaje się nam ludzkich imion w obawie przed naruszeniem praw człowieka
wiem !
będziesz się nazywał pero ! pero !
brzmi jak pies
bo tak się nazywał mój pies
był fajnym psem !
według mnie , w metropolis nie ma miejsca w którym mógłby się ukryć przestępca
o czym ty mówisz ? słyszałem , że tu jest
jeśli dr laughton się ukrywa , z pewnością jest w obszarze 1
obszar 1 ?
- to podziemny świat
- mówi ci to intuicja detektywa ?
to prawdopodobieństwo wykalkulowane przez mój elektroniczny umysł
każdy z robotów ma swoje zajęcie nasze działania są odpowiednio ograniczone
temu robotowi zabroniono działalności na powierzchni
a kim są ci ludzie przebrani za faszystów ?
to partia marduka zajmują się robotami poza obszarem
poruszanie pomiędzy poziomami jest ograniczone według rangi
nieoznaczeni ludzie i roboty mogą się wolno poruszać
- a ten robot był oznakowany ?
- zgadza się
na każdej ulicy jest brama , ale przemytnicy prowadzą innych przez tajemne przejścia , więc wypadki się zdarzają
to powinno być zabronione !
cóż , chyba światło powoduje cień
ten poziom nie jest taki niebezpieczny , ale zależnie od położenia znajdują się tam obszary bez policji , więc uważaj
dobra
nie przyszliśmy tu zwiedzać
książę red
spójrzmy na to , laughton
wygląda doskonale
na pewno nie jest skończona ?
jej układ paliwowy nie jest stabilny , więc
wykorzystałeś maszynerię ożywioną ?
nie !
nigdy bym nie użył nielegalnych środków !
maszyneria ożywiona to tylko prowizorka , nie trwa długo
zbudowałem ją z części mechanicznych
jest największym osiągnięciem w moim życiu !
- kiedy ją skończysz ?
- w ciągu tygodnia
jeśli ją zbyt szybko uruchomię , mogłaby się przeładować , a nawet wybuchnąć
moja mała tima
nikomu cię nie oddam
skończę tylko parę drobiazgów i razem uciekniemy
znam cię
jesteś rock ! jak znalazłeś laboratorium ?
ochrona ojca jest jednym z moich wielu obowiązków
ojca ?
książę red nie ma dzieci
dziecko , które stracił , było dziewczynką
zamknij się !
wiem , co kombinujesz
próbujesz nabrać ojca swoją technologią !
zwykła marionetka nie poruszy ojcowskiego serca
co chcesz zrobić ? !
pracuję nad timą na prośbę księcia reda !
ma co do niej pewne plany ostatnia część dla zigguratu ona zasiądzie na tronie !
to kłamstwo !
ojciec nie pozwoliłby robotowi rządzić zigguratem !
sam go spytaj
zastrzelisz ją ? wiedząc , że " twój " ojciec czeka na tego aniołka ?
nie pozwolę , by robot uwiódł ojca !
nie
nie rób tego !
boże , obdarz mnie odwagą ! daj mi sił do strzeżenia ojca przed złymi maszynami !
pożar !
pali się !
mardukowie podłożyli ogień !
sam widziałem !
nawet mardukowie chcą nas zgładzić !
atlas ma rację !
znaczymy dla nich tyle , co nic !
do broni !
czas , by walczyć !
uspokójcie się
wkrótce ugasimy ogień
tu jest niebezpiecznie ! ewakuujcie się !
to nie miejsce dla robota !
przez was , dranie , straciliśmy pracę ! - a teraz dajecie rozkazy !
- nie czas na kłótnie !
co to ? !
atlas , dlaczego mardukowie podpalili fabrykę ?
jakiś starzec się tu kręcił
czy to on ?
- tak , to on
- dzięki !
ktoś jest w środku !
o , boże !
- wejdź od tyłu - dobra !
szybko !
- trzymaj się , laughton !
- mój notatnik
chcesz notatnik ? !
laughton !
laboratorium laughtona się spaliło ? !
to było doświadczenie
ogień wszystko pochłonął wszystko przepadło
- co z dr laughtonem ?
- znaleziono jego zwłoki
i niewiele więcej był przestępcą , na którego wydano wiele nakazów więc może to było niebezpieczne doświadczenie ?
o co chodzi ? miałeś coś wspólnego z dr
laughtonem ? zamknij się !
zostaw mnie !
chcę być sam
gdzie jestem ?
to był straszny pożar !
straszny ? nie zależy mi na fabryce
pozbyliśmy się czegoś niepotrzebnego
coś jest nie tak
nieważne jak wielki pożar , ten robot był wysokiej jakości
jego szkielet powinien ocaleć
kim jest ten człowiek ?
rock z partii marduka
jest młody , ale wpływowy
mówią , że książę red mu ufa
książę red ?
w jaki sposób książę red jest powiązany z mardukiem ?
książę red założył partię
wydają się nie być powiązani , ale fundusze wpływają od księcia reda
to tajemnica , ale robią to tak otwarcie , że wszyscy wiedzą
gdzie odchodzą ścieki ?
do obszaru 2 , potem do zlewni w obszarze 3
jeśli dotarli tak daleko , nie przeżyją
zwykły człowiek zawsze powróci na miejsce zbrodni
ludzie mieli kiedyś dobre powiedzonka
poszukajmy ponownie pana kenichiego
kim jesteś ?
kim jesteś ?
nie odnosisz się do siebie jako „ja "
kim „ja jestem " ?
" ja jestem "
ty jesteś ja
nie , słuchaj
ty jesteś „ja "
ja jestem " ty "
czekaj
kim jestem ?
tak , tak !
a ja jestem kenichi
kenichi
kenichi
postaraj się wszystko zapamiętać
swoje imię , dom , matkę i ojca
dom ojciec
dzięki
wiem , że to żywność , ale się zepsuła , więc
żywność
tak , wkłada się ją do buzi , i tak się ją je
o , nie !
jak to zjesz , to się rozchorujesz !
nie ? nie mogę jeść ? chora
rozłączenie zbiornika
czas do promieniowania : 40 , 39 , 38 , 37
zasilanie , chłodzenie , układ kontrolny w normie
ostatnia faza cel
magnetyczny cel , błąd w odchyleniu , 025
mechanizm naświetlania , ustawianie ostatecznej pozycji
czas promieniowania - 3 minuty
nie zaszkodzi ludziom , ale roboty na powierzchni mogą ulec awarii
wszystko zapiszemy
dane będą bezcenne
zacznij na poziomie 3
tak jest
promieniowanie wstępne
3 sekundy 2 sekundy 1 sekunda
synteza jądrowa !
- spektrum fraunhofera - na 2 poziomach 35 , 000
40 , 000 45 , 000
gęstość plamy na słońcu - 800 i rośnie
zakłócenie jonizacji ziemi
poziom 3 , radiacja zakończona
wyłączenie głównego układu
udało się !
świat się zakotłuje
posiadasz boską moc w swoich rękach
jeśli dr laughton ukończył timę , zajęła już pewnie tron
to nowa broń , proszę pana powoduje plamy na słońcu , zalewając ziemię promieniowaniem
jak śmią sami coś takiego wymyślić ! ? to zachwieje równowagę władzy !
mimo , że mardukowie ścigają roboty , rebelianci opowiadają się za prawami człowieka podjudzając obywateli , obiecując zmiany w prawach robotów
nawet grupy cywilów popierające roboty protestują , powodując starcia
to wspaniała okazja !
moglibyśmy dopuścić się zdrady stanu w słusznym celu
posiadamy kontrolę nad wojskiem ?
niektóre oddziały stoją za księciem redem , ale nie powinno być problemu
dobra , rozpuść plotki
wznieć niechęć do księcia reda , potem go zaaresztujemy
jeśli spotkasz się z oporem , zaangażuj wojsko !
myślę , że to on zabił laughtona !
nie rozumiem powiązania pomiędzy nim a laughtonem
ciekawe nad czym laughton przeprowadzał doświadczenia ?
co zamierzasz zrobić ?
skoro zabito laughtona , powinienem ogłosić dlaczego
przynajmniej tyle mogę zrobić dla swego klienta
- gdzie on idzie ?
- chyba do obszaru 2
jest więcej podziemnych poziomów ? !
co się dzieje w tym mieście ?
w obszarze 2 znajduje się elektrownia metropolis
obszar 3 to zlewnia ścieków
zlewnia ścieków ?
badał odpływ wody za opuszczoną fabryką
pójdę do centrali po pozwolenie na udanie się na dół
przedłożę też prośbę o poszukiwanie kenichiego dobra
ty draniu !
jesteś na to za stary !
ile ?
obszar 2 jeśli byłby tu jakiś dziwak , wiedzielibyśmy o tym administracja wszystko obserwuje
- jak często schodzisz na dół ?
- 2 razy w tygodniu w celu napraw robotów
to są modele albert ii
to ostatnia grupa , którą muszę sprawdzić
ktoś tu jest ? !
nie , tu zawsze tak śmierdzi !
ludzie by tu nie przetrwali jednego dnia
o co chodzi ?
- ktoś tu jest
- żarty sobie stroisz !
hej , co tam robisz ? !
nie można tu wchodzić !
- jednak żyją - co ?
hej !
co robisz ?
nieważne
to przestępca
powiedz , gdzie jest wyjście !
przestań !
uderzysz sprzęt !
nic ci nie jest ?
co zrobimy ? próbuje nas zabić
ruszaj się !
stoisz na drodze !
ruszaj się , zakuta pało !
ruszaj się !
teraz dobrze ?
to miejsce wygląda dobrze
o co chodzi ?
fifi nie może przejść przez bramę
dzięki za wszystko , fifi
spotkajmy się ponownie
ruszaj się !
to on !
posiadanie broni jest zabronione !
rock z partii marduka !
demonstracje w czasie świąt są zabronione
natychmiast się rozejść
powtarzam , demonstracje podczas świąt są zabronione
- czekaj , kenichi !
- zatrzymaj się !
płać !
- nie ma ich ! - niemożliwe !
przeszukaj cały obszar !
to znaczy wszędzie !
co się dzieje , atlas ?
nie było sygnału !
odwołujemy dzisiaj
pełno tu drani z partii marduka
- ktoś nas wydał ?
- nie , to przez nich
rock ich szuka
pośpieszcie się !
widzieliśmy ich jak się paliła fabryka , prawda ?
jak się nazywacie ?
skąd jesteście ?
nazywam się kenichi
- przybyłem z japonii z detektyw
- co ?
mój wujek jest dziennikarzem , pomagam mu
- dlaczego rock cię szuka ? !
- nie wiem
właśnie zaczął strzelać
- mamy ci uwierzyć ?
- powinniśmy ich zabić
spokojnie !
nie jesteśmy gangiem
jest dziennikarzem
może opowiedzieć światu o metropolis to więcej niż marzyliśmy
to sprawa życia i śmierci nie mamy czasu , by robiono nam zdjęcia !
ale mamy prawo , by wybrać jak zginiemy chcę zginąć jako rewolucjonista
patrz
wygląda jak anioł
tak , jest aniołem
tutaj dwie lub trzy rodziny dzielą ze sobą pokój
nie ma szkół ani pracy
żywność jest racjonowana , ale z powodu świętowania na cześć zigguratu nawet tego nie dostajemy
co oznacza " ziggurat " ?
to nazwa wieży zbudowanej w babilonie
najsławniejszą była wieża babel
wiesz , co się z nią stało
król babilonu rozgniewał bogów i została zniszczona
historia się powtarza
księcia reda spotka to samo
tym razem my ją zniszczymy , nie bogowie
popełniłam błąd ?
nie , to nie to
urosły ci tylko włosy
jakie lubisz włosy ?
co ?
lubię takie , jakie mam
poćwiczmy
- dobra , następnie
- tima co ?
co to ?
tima
moje imię
rozumiem ! przypomniałaś sobie !
to cudownie , tima
wkrótce będziesz więcej pamiętać
dziękuję kenichi
o , zapomniałem pożyczyłem od atlasa
kenichi
tak
przydałaby się nam pomoc wojska
większość z oporu popiera wszczęcie akcji , ale wszyscy się wahają nie jesteśmy pewni naszej siły
ostatnia faza świętowania zigguratu zaczyna się paradą marduków
wtedy ich stłamsimy chcę , byście wzięli ziggurat szturmem
prezydent w przemowie ogłosi , że aresztowano księcia reda za zdradę stanu
przejmiemy władzę i prezydent boon będzie dowodził wojskiem
wtedy metropolis będzie miał normalny rząd
a my będziemy posiadali głos , jako nowa partia polityczna
oczywiście , mój drogi atlasie
prezydent przyjmie was wszystkich
cholera , sam sobie nie wierzę !
nareszcie go znalazłem , i patrz co się dzieje
wybacz , że nie byłem bardziej pomocny
o czym ty mówisz ?
pomogłeś mi tu , nie odróżniam wschodu od zachodu
nie martw się o kenichiego
nie wygląda na zbyt wiele , ale
przestań !
jak można tak robić ? !
" uważaj na siebie
roboty , chować się
będzie zamach stanu " co ? !
zamach stanu ?
patrz uważnie , kenichi
chcę , byś światu o wszystkim opowiedział !
zabrakło mi tchu
lepiej stąd chodźmy , pero
nie poradzimy sobie z tym
poproś o pomoc od centrali czekaj !
nie mogę cię tu zostawić
najpierw pójdą za robotami
nic mi nie będzie
- co ? !
- a co ważniejsze , muszę zadbać o twoje bezpieczeństwo , gdyż nie jesteś stąd
dobrze !
postaraj się ich nie prowokować aż wrócę ! rozumiesz , pero ? !
co to ? możesz sam pilnować tej bramy ?
zabrania się demonstracji podczas świętowania
proszę się rozejść
nie mogę
już prawie czas
dlaczego ludzie używają przemocy , by rozwiązać problemy ?
dobre pytanie
to prawda , że emocje są źródłem naszych problemów
ale bez względu na nie , musimy posuwać się naprzód
gdyż bez nich nic nie znaczymy
czas na wiec
kiedy powinniśmy to ogłosić ?
wszystko się wyjaśni do 1300 może o 1500 lub 1530 ?
o co chodzi , ministrze ?
nie możesz się doczekać ?
tak , prezydencie
dano mi nieprzyjemne zadanie
co to ? !
dranie ! pracujesz teraz dla księcia reda !
jestem sprawiedliwy w stosunku do historii
czekaj , mogę wyjaśnić
po co ?
dlaczego ludzie zawsze ranią roboty ?
nazywają to rewolucją ?
zamach stanu się nie powiódł
w metropolis panuje stan wojenny w imię księcia reda
złóżcie broń i poddajcie się
powtarzam zamach stanu się nie powiódł
w metropolis panuje stan wojenny w imię księcia reda
złóżcie broń i poddajcie się
kenichi !
hej , kenichi !
wujku !
więc jesteś bezpieczny !
tak się cieszę
nic ci nie jest , wujku ?
o , to nic takiego
kto to ?
ma na imię tima
jest z laboratorium , oboje uciekliśmy
tima , przedstawię cię to mój wujek
wujek
atlas !
podpuścili nas
nareszcie się spotykamy
nie ruszaj się !
nie opieraj się
jeśli ją oddasz , masz szansę na przeżycie
zamknij się ! nie dotrzymasz słowa ! wiem , co kombinujesz
ty mały
tima , zabierz broń !
teraz mi ją oddaj
nie dawaj mu jej !
potrafisz mnie zastrzelić ?
jestem człowiekiem !
rock !
co się tu dzieje ? co robiłeś ?
przetrwałaś ?
co to ma znaczyć ? !
powiedziałeś , że tima spłonęła w pożarze ! mówiłeś , że nikt nie przeżył !
skąd w ogóle wiesz o timie ? !
odpowiedz !
z pełnym szacunkiem , to ty musisz zasiąść na tronie
nie możemy powierzyć zigguratu robotowi ! - nie możemy oddać przyszłości
- ty głupcze !
robot
myślałeś , że możesz mną manipulować ? !
ufałem ci
wykorzystałeś mnie !
nigdy mi się tu nie pokazuj !
więc nająłeś laughtona
no i co ?
przybyłem z japonii , by go aresztować
nazywam się shunsaku ban
wsiadaj
- a co z kenichi ?
- jak skończymy robotę
muszę się zobaczyć z komisarzem notarlinem
przeniesiono go
nie ma jeszcze następcy
mówiąc prawdę , partia marduka pojmała mego bratanka przez pomyłkę
więc zgłoś się do ambasady !
obecnie jako naród , dotkniemy niebios !
z przyjemnością ogłaszam kulminację ludzkiej historii osiągnięć naukowych ! nasza potęga będzie promieniować w całym świecie
sake
podgrzej ją dobrze
mamy gorącą whisky lub gin , panie japoński detektywie
gorąca whisky w butelce
idioci , idioci ! do diabła z zigguratem !
mardukowie to wielkie gówno ! to dranie !
proszę
hej , to był rock
podobno opuścił partię
nie pomyślałbym , że tu będzie
- dzięki
- trzymaj się
jakiś mężczyzna poprosił , by ci to dać
odmówiłam , ale prosił , by nic nie mówić księciu redowi
mówiłam , że nie mogę , ale mówił , że się nazywa kenichi nie mogłam się oprzeć
" droga timo , wybacz , że nie mogę tego dostarczyć osobiście ale nie mogę nigdzie chodzić
wkrótce wyjeżdżam z kraju , więc chciałbym cię jeszcze raz zobaczyć "
co się dzieje , enmy ?
naprawdę , natychmiast ją odeślij
jeśli ktoś się o tym dowie , będę miała problemy !
nie martw się
to nie potrwa długo
nie chciałem tego robić
lepiej już pójdę
nabrałeś mnie
to była jedyna metoda , bym mógł z tobą porozmawiać
gdzie jest kenichi ?
pozwól mi go zobaczyć
niewiarygodne
trudno uwierzyć , że jesteś robotem
ojciec miał dobry powód , by wybrać laughtona
o czym ty mówisz ?
o tym , że jesteś robotem
nie masz racji
nie jestem robotem
więc kim jesteś ?
człowiekiem ?
kto jest twoim ojcem ?
gdzie on jest ?
moim ojcem jest kenichi
i myślą , że taka kukła jak ty może zasiąść na tronie ? !
jeśli nic nie wiesz o kenichim , wracam
tima zaginęła ? ! tak , proszę pana !
ty idioto ! pilnuj tego !
odkryjmy tajemnicę tego nadczłowieka , którego ojciec tak pragnie
trzymaj się , laughton !
mój notatnik
chcesz notatnik ? !
nie martw się
ukarałem trochę rocka
za co ?
też szukam kenichiego
i będę potrzebował twej pomocy
potrzebował ?
myślę , że trzymają go w zigguracie
jeśli się podłączysz do sieci zigguratu , będziesz mogła się dowiedzieć gdzie jest
mogę to zrobić ?
wystaw rękę
i jak ?
wiem , gdzie jest kenichi w wieży
udało ci się !
więc jest tam , gdzie myślałem !
co zrobiłam ?
prawda nie wiesz , kim jesteś
co masz na myśli ?
tak jest jak się tylko dowiemy
książę red ?
jak leci ?
wytropimy sygnał zasilanie było tak mocne , że rozgałęźnik się przepalił
- znalazłem !
- gdzie ?
obszar 1 , blok południowy 17 , „hotel kokosy "
powiedz mi jestem człowiekiem ?
czy jestem ?
to prawda , różnisz się od innych robotów
nie , jestem człowiekiem
tak jak kenichi
tak oczywiście , że jesteś
tak czy siak , musimy najpierw uratować kenichiego
szukaliśmy cię
gdzie się wybierałeś ? powiedz , albo cię aresztuję za porwanie !
pytasz nie tego , co trzeba !
zapytaj syna , jeśli chcesz prawdy
nie wiem co knujesz , ale uważam , że definitywnie pracowałeś z dr laughtonem
a jego morderstwo sprowokowałeś ty lub rock by zachować twoją tajemnicę
- zabrać go
tędy !
to tron , który zbudowano tylko dla ciebie
wkrótce będziesz stąd rządziła całym światem
naprawdę ?
dlaczego ?
bo takie jest twoje przeznaczenie
wkrótce zrozumiesz
trzymaj się , kenichi !
to ja ! patrz !
hej , kenichi !
dranie ! co mu zrobiliście !
nie umiera
tylko go trochę uspokoiliśmy
wniosę co do tego protest poprzez ambasadę !
- to będzie kryzys dyplomatyczny !
- naprawdę ?
nie wiedziałem , że jesteś taką ważną osobistością
przyjmij moje przeprosiny
nieważne skąd pochodzisz , wszyscy uchylą czoła przed timą
- rośnie tak , jak przewidywaliśmy - przywróć kenichiego
o co ci chodzi , tima ? komu zależy na małym chłopcu ?
posiadasz siłę , by rządzić całym światem
co to za siła ?
jestem człowiekiem ?
czy tylko maszyną , jak te biedne roboty ?
jak można tak mówić ? !
jak mogłabyś być taka , jak to byle co ? !
więc jestem człowiekiem , tak jak kenichi ?
o czym ty mówisz ? !
nie jesteś tylko człowiekiem ! nie jesteś podrzędna , poddająca się emocjom , zagubiona przez miłość i moralność
jesteś nadczłowiekiem !
więc naprawdę jestem
przyniosłam nową odzież dla panny timy
prawda , jesteś robotem jesteś najwspanialszym i najbardziej wzniosłym stworzeniem !
to kłamstwo
posiadam miłość i emocje , które określasz jako ludzkie
nie jesteś jeszcze kompletna potrzeba ci tylko czasu
wahania twej mocy przybierają kształt miłości i emocji
pewnego dnia połączysz się z tronem nadczłowieka i staniesz się komputerową bronią władającą światem !
wtedy te wspomnienia i emocje zostaną całkowicie wymazane !
skąd posiadasz te informacje ?
wciąż jestem detektywem
czas się przebrać , panno timo
ojcze , otwórz oczy
jak u ?
co to ma znaczyć ? !
ty masz siedzieć na tym tronie
jesteś jedynym , który może być naszym liderem , ojcze
co ty ?
przebudziłeś się
jestem sztucznym człowiekiem maszyną stworzoną , by zniszczyć świat
nie , nie zniszczyć !
odbudować !
przestań !
- kto włączył przełącznik ? !
- sam się włączył !
- odetnij napięcie !
- nie da rady !
dr ponkotz !
- co oznacza ten alarm ? !
- generator się popsuł !
- co się dzieje , doktorze ?
- cóż
przestań , tima !
zniszczysz ziggurat !
to kara za roboty
wspomnienia timy łączą się z naszą bazą danych zaczyna szaleć
i gniew boży zstąpił na wieżę babel
nie !
nie jest już timą !
dobrze , rozumiem
jeśli nie zatrzymamy generatora , będzie po nas !
za godzinę , prawdopodobieństwo przetrwania ludzkości będzie 30%%%
zarządzam zigguratem , i cały arsenał zostanie uruchomiony w ciągu 30 minut o , boże !
celem ataku są największe miasta świata i 7586 obiektów
zniszczenie ludzkości napromieniowaniem i bronią nastąpi za 17 godzin 27 minuty
słyszysz , książę red ? !
twój nadczłowiek mówi , że nie potrzebuje ludzi !
nie idź !
doktorze , straciliśmy kontrolę
jak to możliwe ?
wynoś się !
robotom tu nie wolno !
tima , to ja !
kenichi !
to ja , kenichi !
przestań !
nie pozwolę , by takie byle co jak ty zabiło mego ojca !
tima , chwyć mnie za rękę !
- jestem kenichi
kim jesteś ?
- kim jesteś ? nie
słuchaj , odnosisz się do siebie jako „ja "
szybko , chwyć mnie za rękę !
kim jestem ?
gdzie to znalazłeś ?
fifi ?
fifi !
wujku !
wujku ? chciałbym jeszcze trochę zostać
kim jestem ?
" cyrk "
" cyrk "
" znów nie trafiłaś w koło "
" ojcze , nie mogłam inaczej "
" za karę nic dziś nie jesz "
" i wy macie być śmieszni ! "
" patrzcie na cyrk ; pusty ! "
w pobliżu widowiska , głodny i bez grosza
" proszę "
" proszę przeliczyć "
" nic nie brakuje ? "
" daj mi te pieniądze ! "
" jak się stąd wychodzi ? "
" nudziarze ! "
" wynocha ! "
" gdzie jest ten śmieszek ? "
" sprowadźcie tego śmiesznego pana ! "
śmieszny pan
posiłek po występie
" ojciec mi nie pozwoli "
" chcesz pracować ? "
" przyjdź tu jutro rano , zrobimy z tobą próbę "
wczesnym rankiem następnego dnia
głodna
" wracaj do domu ! "
" ja mieszkam tutaj "
" przepraszam , moja laska "
próba
" bądź śmieszny "
" to jest okropne ! "
" zagrajcie numer william " a tell " a "
" przypatrz się zobaczymy , czy umiesz to zrobić "
" spróbuj to powtórzyć "
" zagrajcie numer cyrulika "
" teraz mam cię uderzyć "
" teraz uderz mnie ! "
" nic nie widzę "
" chwileczkę ! "
" nie omówiliśmy jeszcze warunków "
" idź stąd i nie wracaj ! "
" zaczyna się ! "
" nie wchodzi pan ? "
" pan odchodzi ? "
" nie porozumieliśmy się co do warunków "
" dziękuję za jajko "
występ
problemy z personelem
" co z naszą zapłatą ? "
" do pracy ! "
" odchodzimy stąd ! "
" odeszli "
" znajdź kogoś ! "
" chcesz pracować ? "
" nie dotykaj tego guzika ! "
" on jest sensacją ale o tym nie wie , zatrzymajmy go jako pomocnika "
cyrk prosperował , lecz nie pomocnik ; dziewczyna też wiodła równie trudny żywot
" zajmij go czymkolwiek i niech nie wie , że jest gwoździem występu "
chory koń
" wdmuchnij tę pigułkę w gardło konia ! "
" koń dmuchnął pierwszy "
" otwórz drzwi , szybko ! "
" mówiłam ci , że lwy są niebezpieczne ! "
" gdzie pigułka ? "
" chodź tu ! "
" muszę iść do doktora ! "
" to wstyd , że tak cię wykorzystują ty jesteś przecież gwiazdą spektaklu "
" oczywiście !
cały tłum i oklaski są dla ciebie "
" wiedziałem ! "
" jeśli uderzysz ją opuszczam cyrk ! "
" co więcej , chcę tyle , ile jestem wart "
" dam ci 50 dolarów na tydzień "
" sześćdziesiąt ! "
" podwajam ! "
" nie mniej niż sto "
następne przedstawienie
sukces trampa uczynił życie łatwiejszym dla dziewczyny i dla niego samego
" merna , niech wróżka przepowie ci przyszłość ! "
" widzę miłość i ślub z ciemnym , przystojnym mężczyzną który jest blisko ciebie "
nowa dodatkowa atrakcja rex , linoskoczek
" przepraszam "
" proszę bardzo "
" dam ci za to pięć dolarów "
" stało się ; zakochałam się ! "
" on jest linoskoczkiem ; dopiero co go spotkałam "
" spiesz się twoja kolej ! "
koniec występu
" co się stało ?
nikt prawie się nie śmiał ! "
" to mój przyjaciel "
" nie lubię linoskoczków "
czas przyniósł do cyrku wiele zmian
nowe nadzieje i nowe ambicje
jego nowa ambicja
" zapomnij o linie ; lepiej bądź znów śmieszny , albo za drzwi ! "
następne przedstawienie i ani jednego uśmiechu
" mam tego dosyć ; daję ci ostatnią szansę "
" gdzie jest rex ? "
" rex , linoskoczek , nie pokazał się "
" jest tu rex ? "
" możesz zrobić jego numer , prawda ? "
" jak nie , to cię zwalniam ! "
" zrobię to ; znajdź jego kostium ! "
" oto jego rzeczy ! "
" po niej wasza kolej ! "
" zabije się "
" w porządku ; ubezpieczyłem go "
" powoli , przed tobą jeszcze jeden numer "
" co to ma znaczyć ? "
" ja zajmuję jego miejsce na linie "
" zabijesz się "
" o nie , bogowie czuwają nade mną "
" dam ci pięć dolarów , jeśli to zrobisz "
" nikomu ani słowa "
" nie rób tego , proszę "
" zapomniałeś rajstop "
" twoja kolej ! "
" jesteś wyrzucony ! ! ! "
tej nocy
" uciekłam z cyrku "
" i nigdy już tam nie wrócę "
" zabierzesz mnie ze sobą ? "
" mam pomysł "
" czekaj tu "
" widziałeś mernę ? "
" ona uciekła "
" ja nie mogę jej pomóc "
" jest jedno wyjście "
" ona jest tam teraz ? "
" prowadź mnie do niej ! "
następnego ranka
cyrk gotowy do odjazdu
" więc wróciłaś ty ! "
" mówisz do mojej żony ! "
" jedziecie z nami na dalsze występy ? "
" jeśli go zabierzesz "
" ostatni wagon dla ciebie "
" wsiadaj z nami "
- chcemy z panem pomówić - co się stało ?
ktoś uregulował rachunek ?
- chcemy naszych pieniędzy
- właśnie
- waszych pieniędzy ?
- chcemy nasze pensje
więc chcecie moich pieniędzy ?
ładnie to tak ?
czy ja chcę waszych ?
gdyby żołnierze waszyngtona chcieli pieniędzy , gdzie by ten kraj dziś był ?
- przecież chcieli
- no i gdzie jest waszyngton ?
nie , przyjaciele
pieniądze nie dadzą wam szczęścia , a szczęście nie da wam pieniędzy
chyba palnąłem coś mądrego , choć wątpię
- chcemy naszych pieniędzy
- coś wam powiem
jak będziecie ciężko pracować , zapomnicie o pieniądzach
weźmy się do pracy i zróbmy z tego porządny hotel
ja kupię papier listowy za rok , jak będziecie grzeczni , dokupię koperty
dostaniecie po darmowym kocu
nie będzie opłat za kołdry
floryda stwarza wielkie możliwości
przyjechałem tu trzy lata temu , nie mając ani centa
- teraz mam jednego centa
- wszystko pięknie , ale od 14 dni nie dostajemy pensji chcemy nasze pensje
chcecie być zależni od pensji ?
pytam was
- nie
- co czyni was zależnymi od pensji ?
pensja
chcę , byście byli wolni
pamiętajcie , wolność ponad wszystko oprócz " colliers " i " saturday evening post "
bądźcie wolni
jeden za wszystkich , wszyscy za mnie , ja za was , trzech za pięciu , sześć godzin za ćwierć dolara
telegram do pana , panie hammer
widzicie
interes się rozkręca
teraz bądźcie cicho
" przyjeżdżamy pociągiem o 16 : 30
proszę zarezerwować 2 pokoje i 3 dziury " to chyba myszy
" jak spodoba się nam jakaś działka , kupimy ją od ręki " - widzicie ?
sprawy idą po naszej myśli - kto nadał ten telegram ?
western union
oni mają forsy jak lodu
o 16 : 15 ?
sam po nich wyjdę
- jeszcze jeden telegram
- do wieczora będziemy mieli komplet
będą takie tłumy , że tysiące ludzi odejdą z kwitkiem
" jeśli jest inny hotel w cocoanut beach , odwołuję rezerwację "
wiedziałem
to było zbyt piękne
zaraz " ps
ciocia fanny powiła 4-kilowego chłopczyka
zapraszam na ślub "
wszystko w porządku
jesteście zaproszeni na ślub 4-kilowego synka cioci fanny
- hurra !
- ale to dopiero za kilka lat
a na razie głowa do góry i do roboty
z życiem
i zapomnijcie o pieniądzach
bo i tak ich nie dostaniecie
widzisz ?
tańczą za swoje pieniądze
jamison , jadę na stację odebrać gości
jak nie wrócę , znaczy , że wciąż czekam na pociąg
zajmij się wszystkim podczas mojej nieobecności
- może pan na mnie polegać
- świetnie
jak przyjdą jacyś goście , zajmij się nimi
- i pomyśl czasem o mnie - oczywiście
- kiedyś wrócę
- oczywiście
zostaw światło w oknie , jeśli znajdziesz jakieś okno
- dobrze
- do widzenia , jamison
cześć , harvey
coś taki markotny ?
bob adams odbił ci polly potter ?
nie obchodzi mnie ten recepcjonista
ale miliony potterów jak najbardziej
dawniej umiałeś korzystać z pieniędzy
zostawmy ten temat
tylko ożenek z polly pomoże ci spłacić długi
- potrafię zadbać o siebie
mam plan , na którym skorzystamy oboje jaki plan ?
widziałeś naszyjnik z brylantów pani potter ?
oczywiście
co to ma wspólnego z nami ?
mieszkamy w sąsiednich pokojach
ona w 318 , ja w 320
- drzwi nie są zamykane na klucz - co z tego ?
pudełko z kosztownościami trzyma w toaletce pod kluczem
a klucz nosi w torebce
musisz zdobyć ten klucz
to nie będzie proste , ale może da się zrobić
zaproszę panią potter i polly na kolację
co zamierzasz ?
może uda mi się wykraść klucz podczas kolacji
mądrze mówisz
jak za dawnych lat
ja zajmę się bobem adamsem
to cocoanut manor
znasz to wzgórze ? też pytanie
oczywiście , że znam to piękne wzgórze
przez to piękno nic tam nie wybudowano
- nie można wyciąć drzew ?
- zbyt drogi interes
w zeszłym miesiącu oglądał je john w berryman
berryman praktycznie sam zbudował palm beach i miami , ale nie chce w to wejść
kiedy taki człowiek nie chce inwestować , nikt nie chce
- znasz się na architekturze ?
- nie , ale chętnie się nauczę
narysowałem mapę wzgórza i plan zabudowy
wcale nie trzeba wycinać drzew
wpasowałem budynki w wolne miejsca
wysłałem plan berrymanowi otrzymałem odpowiedź , że go analizują
wspaniale
hammer o tym wie ?
jeszcze nie
jeśli plan zostanie przyjęty , ja zaprojektuję budynki
wreszcie będę pracował jako architekt
jak wszystko się uda , będzie to najpiękniejsze miejsce na świecie
będzie najpiękniejsze , jeśli ty w nim zamieszkasz
zobacz , co napisałem
" raj dla polly i boba "
wygląda świetnie
kiedy mogę się wprowadzić ?
- w każdej chwili
- piękny sen
sprawmy , by się ziścił
" nastanie piękny dzień "
" kiedy ziści się " mój sen "
uśmiech na mojej twarzy zagości
" kiedy mój sen się " ziści "
" hiszpański pałac , który wzniosę
" będzie dla nas miłosnym gniazdkiem "
zamieszkamy w nim , ty i ja
" kiedy ziści się " mój plan "
" odkąd cię " poznałem "
" tak się " rozmarzyłem , że wciąż śnię
wspaniałe sny
" oczyma wyobraźni raj nasz widzę
" kiedy spełni się " mój sen ? "
wspaniały sen
nastanie wspaniały dzień
" kiedy ziści się " mój sen "
uśmiech na mojej twarzy zagości
" kiedy mój sen się " ziści "
" hiszpański pałac , który wzniosę
" będzie dla nas miłosnym gniazdkiem "
zamieszkamy w nim , ty i ja
" kiedy ziści się
mój plan
- tylko popatrz
- patrzę
- jakie to urocze
ciekawe kto to
- przekonajmy się
czerwony kapturek powiedział : " wilk , wilk "
- witam , panno potter
- witam
twoja mama wszędzie cię szuka , polly
jak zwykle i jak zwykle mnie znajduje
znasz mamę
dziękuję
to była piękna historia , panie adams
chętnie usłyszę jej dalszy ciąg
do widzenia
ja też mogłabym jej posłuchać ?
oczywiście
ty też chcesz , yates ?
nie , dzięki
wiesz , co spotyka niegrzecznych chłopców opowiadających bajki ?
oczywiście
żenią się z księżniczkami
na razie
zamieszkamy w nim , ty i ja
" kiedy ziści się
mój plan
miły chłopak
tacy zazwyczaj dostają to , czego chcą
nie zawsze
jeszcze mogę go pokonać
cuda się zdarzają
polly , znowu byłaś z tym panem adamsem
ale bardzo krótko
dlaczego moja córka zadaje się z recepcjonista , kiedy ma okazję wyjść za kogoś z rodziny yatesów , - tego nie mogę zrozumieć
- kogo obchodzą yatesowie ?
a bob jest architektem
w recepcji pracuje tymczasowo
ten , kto pracuje w recepcji , jest recepcjonistą
pamiętaj , że nikt z potterów nie był zamieszany w żaden skandal
a wuj dick ?
wszyscy wiedza , że był wtedy pijany
poza tym nie podoba mi się , że całe noce spędzasz na plaży
weź coś na bezsenność i nie pij tyle kawy
przepraszam
jak poszło z pociągiem ?
w porządku , nie przejechał mnie
wiem , co jest nie tak z hotelem ja też
wylatujesz
weź swój kapelusz , mój płaszcz i won
- może sezon jeszcze się nie zaczął
- może hotel jest zamknięty
proszę się nie martwić , niedługo zacznie pan zbijać kokosy
i słać łóżka
zabieraj się stąd
sam obsłużę te tłumy gości
600 pokojów , a ty śpisz w recepcji
- dzień dobry
- proszę gwizdać na skrzyżowaniu
właśnie takiej kobiety szukałem
opowiem pani o rynku nieruchomości
nikomu jeszcze o tym nie mówiłem przykro mi , ale
wie pani , że ceny nieruchomości wzrosły o 1929 od 1000% ?
to największy wzrost od czasów sophie tucker
floryda to chluba ameryki , a cocoanut beach to zakała florydy ?
- mówił mi pan o tym wczoraj
- ale opuściłem przecinek
organizujemy aukcję w cocoanut manor , w tym okropnym uroczym zakątku
proszę przyjść
będzie rozrywka , kanapki i licytacja
jeśli nie lubi pani licytować , pogramy w remika
oto cocoanut manor
" 42 godz pociągiem z time square
" 2600 km w linii prostej , 2900 km w krzywej "
" tu schodzą się ścieki z ameryki i frajerzy z florydy "
to najbardziej ekskluzywna dzielnica mieszkalna florydy
nikt tu nie mieszka
proszę zapytać o klimat
- jaki
- dobrze , że pani o to pyta
nasze motto brzmi : " bez śniegu , bez lodu , bez gości "
- floryda to najwspanialszy stan w unii - naprawdę ?
weźmy klimat
a nie , już go wałkowaliśmy
weźmy owoce , gruszki aligatora
może pani wziąć wszystkie
co mi tam
- wie pani , skąd się biorą ?
- nie mam zielonego pojęcia
bo nigdy nie była pani aligatorem niech pani więcej tego nie robi
czasami trzeba wielu lat , by skojarzyć gruszkę z aligatorem
- nie przepadają za sobą
- nie ?
wie pani , ile gruszek wysyła się co roku i zakazuje wracać ?
- nie wiem
- wszystkie jak leci
floryda żywi cały kraj , a mnie nikt nie żywi o tym chcę z panią porozmawiać
oraz o hodowli bydła
to nie jest osobista wycieczka
floryda hodowlą bydła stoi
mamy długorogie , krótkorogie i rogale
mogę coś powiedzieć ? nie
jeszcze nie skończyłem
gdzie pani będzie , jak skończy 65 lat ?
czyli za jakieś trzy miesiące
gdybym kupowała , wolałabym coś w stylu palm beach
wczorajsze atlantic city ?
jutrzejsze slumsy ?
a ludność cocoanut beach podwoiła się w zeszłym tygodniu - tak ?
- urodziły się trzy buldogi
rano spodziewamy się kózki
obawiam się , że muszę już iść
zanim pani pójdzie , pokażę pani rurę ściekowa , jaką będziemy kłaść
nikt nie wciśnie pani byle rury
to 20 cm kawałek rury
właściciele posesji zdecydują o długości
jak będzie pat , sprawa trafi do sądu najwyższego powiem pani coś w sekrecie
prezes sądu najwyższego ma bzika na punkcie tej rurki
proszę ją wziąć
do zobaczenia wkrótce
po co mi ona ?
nie chcę jej
halo
tak ?
woda z lodem w 318 ?
poważnie ?
skąd się tam wzięła ?
mam przynieść ?
to co innego
ma pani lód ?
ja nie mam
tu jest cocoanut beach : ani śniegu , ani lodu
ale dam pani figę z makiem
słucham ?
i nawzajem
pani thompson prosi , by zarezerwował pan dla niej stolik - w ustronnym miejscu
- ustronnym ?
powiedz jej , że może zjeść w hallu
powinniśmy upiększyć to miejsce
wygląda okropnie
obsługa
obsługa , do nogi
- co się stało z naszą obsługą ?
- nie widziałem ich
wyleję kilku z nich
daj wiadro
pokręć się tutaj
jak wejdzie ktoś , kto wygląda na klienta , zwiąż go i oznakuj
spójrz na niego
jest ubrany lepiej ode mnie
hej , daj spokój
chodź tutaj
- witam panów
- witam
zwodzicie mnie w kółko ?
panowie w jakiej sprawie ?
- przysłaliśmy telegram
- miło mi
- dziwne
sam kiedyś wysyłałem telegramy
miło mi cię poznać
w porządku
nie ma się czego bać
ty możesz zostać , ale pozbądź się tego świstaka
co was do nas sprowadza ?
- mamy rezerwę
- rezerwę ?
chcemy pokój bez łazienki
rozumiem , zostaniecie tylko na zimę
zobaczę , co da się zrobić
- dobrze , na lato też
- przykro mi , nie mamy wakatów
- nie ma wakatów
- ale mamy wiele pokoi
w porządku , weźmiemy pokój
chcesz pokój ?
- weźmiemy wakat
- chłopcze , weź bagaż tych panów
hej , co jest
- ta walizka jest pusta
- wypełnimy ja , zanim wyjdziemy
opróżnicie ja , zanim ja wyjdę
podpiszcie tutaj i sprawa załatwiona
spójrz na niego przestań
śmiało , chłopcy
trzy rzuty za pięć
- nigdy nie pudłuje
- wygrałeś cygaro
kto następny ?
zapraszam
tym nie rzucaj
to zamiejscowa
dobrze
jaki chcecie pokój ?
apartament ze szwedzkim stołem ?
wezmę suterenę z polakiem
suterena jest w pakiecie ze stołówką
to zupełnie inna rozmowa , nie mogę
proszę
pomogę ci
dzisiejsza poczta jeszcze nie przyszła
przydałbyś mi się pierwszego
- telegram do pana hammera
- telegram ?
powiedz im , że jutro wyślę pieniądze
jaki ma być pokój ?
pojedynczy ?
- podwajam
- widzę , że lubisz ryzyko
- niezły dowcip
słucham ?
musi pan mówić głośniej
będzie słychać , jak pan wyjmie nos ze słuchawki
żartowniś z ciebie
halo , o co chodzi ?
chce pan wiedzieć , gdzie można złapać panią potter ?
nie wiem
ma łaskotki
panowie , muszę
jest głodny
zjedz sobie kwiatka
to gryka
wybierz sobie najładniejszego
cieszę się , że ci smakuje
muszę was na chwilę przeprosić , mam coś ważnego do załatwienia
pójdę na górę po sondę do płukania żołądka
wrócę za kilka minut
wy tymczasem
- róbcie swoje
- hej , rób swoje
dobrze
halo ?
nie ma wolnych pokoi
nic nie ma
żadnych gości
podeślę wam kilku
do usłyszenia
wzywał pan ?
hej , chodź
zostaw dziewczynki
szybciej
- a więc postanowione , bądźmy ostrożni - dobrze
dlaczego drzwi między waszymi pokojami są otwarte ?
- powiedziałam jej , że mam do niej zaufanie
przestań
- dalej
tańczymy
- doprawdy !
chodź , penelope
trzymajmy się z daleka od tego lumpa
umpa-umpa
- chętnie bym takich zabił
- czekaj
- wstrzymaj się trochę
wiem , co zrobić
- z nimi ?
kiedy kradzież naszyjnika wyjdzie na jaw , trzeba będzie znaleźć winnego
- oni będą idealni
- niezły pomysł
jak chcesz to zrobić ?
trochę z nimi poflirtuję , zaproszę ich do swojego pokoju
złożę na nich skargę w dyrekcji
ktoś zobaczy , jak się kręcą obok pokoju pani potter
- rozumiesz ?
- jasne
ty masz głowę
dziękuję , łaskawco
- muszę lecieć
na razie - cześć
co robisz ?
tylko byś jadł
musimy skombinować jakieś pieniądze
dla pieniędzy zrobiłbym wszystko
mógłbym nawet zabić
nie , ty jesteś moim przyjacielem
ciebie zabiłbym za darmo
z czego się śmiejesz ?
jesteś tu od trzech godzin , a niczego nie ukradłeś
co tam masz ?
ładny zegarek
dobra robota
to wszystko ?
- ja cię chyba skądś znam
- poddaję się
skąd ?
chwileczkę
mam tu kilka zdjęć
pokaż twarz
ty też
dobrze , sam zrobię minę
czemu mnie popchnąłeś ?
chcesz się bić ?
dalej , chodź
nie kopiemy w tyłek
- o co się bijecie ?
- to mój przyjaciel
to tylko zabawa
co tu robicie ?
jak się nazywasz ?
wydajecie mi się podejrzani
posłuchajcie
na razie nic na was nie mam , ale będę miał na was oko
mam waszą kartotekę w kieszeni
wystarczy , by was wsadzić , jak tylko zaczniecie kombinować
jasne ?
no i co , mądralo
musiałeś wszcząć bójkę przy tym detektywie ?
nie mogłeś trochę zaczekać ?
co tam masz ?
odznakę
dobra robota
nie jest już detektywem
teraz ty nim jesteś
pospieszcie się
pociąg odjeżdża za kilka minut
proszę powiedzieć , kiedy jest następny pociąg do filadelfii ?
jeden na tydzień , a czasami dwa na dzień
- dziękuję
- nie ma za co
dobra robota
trochę ciasna
trzeba coś wyjąć
dobrze , możesz to zatrzymać
tego mi było potrzeba
teraz wyglądam jak człowiek
- witaj
- witam
- ładna marynarka
- podoba ci się ?
wyglądasz w niej jak książę walii - lepiej
- skąd ją masz ?
to moja marynarka
- twoja ?
- moja
- przecież jest za duża
- wiem
co robisz dziś wieczorem ?
ty mi powiedz
nie waż się przyjść do pokoju 320 o 23 : 00
dobrze , przyjdę o 22 : 30
widziałeś moją chusteczkę ?
zdawało mi się , że ją upuściłam
mniejsza o chusteczkę , tak naprawdę chodzi mi o ciebie
czy ktoś ci już powiedział , że wyglądasz jak książę walii ?
myślałam , że sama to wymyśliłam
wiesz , kim jestem ?
wiesz , jaki jest numer mojego pokoju ?
będę tam o 23 : 00
czy ktoś ci już powiedział , że wyglądasz jak książę walii ?
nie ten obecny ten stary
wierz mi , kiedy mówię walia , mam na myśli walenia
umiem odróżnić walenia od kaszalota
mówiłaś , że mieszkasz w pokoju 318 ?
jako właściciel tego hotelu mam całą wiązkę kluczy do pokojów - wiązkę ?
- tak , to po francusku " kilka "
wiesz , " daję ci wiązkę róż "
połóż się
gdybyśmy znaleźli mały domek
wiem , że to nic trudnego , ale może lokatorzy nie chcieliby go opuścić
gdybyśmy znaleźli pusty domek , tylko dla siebie , gruchalibyśmy jak dwie gąski
to znaczy , gęgalibyśmy jak dwie gąski
- wie pan , co chce powiedzieć ?
- tak , co innego niż myślę
chodziło mi o to , że gdybyśmy mieli mały domek , byłabyś w środku , a ja na zewnątrz próbowałbym się dostać albo wydostać
nie , ja byłbym w tobie , ty na mnie
ty tyłem , ja do góry
jeśli nie odezwę się do piątku , nic z tego nie będzie
nie rozumiem
mówię , że twoje oczy błyszczą jak spodnie z niebieskiej serży
- pan mnie obraża
- nie chodziło mi o ciebie , tylko o spodnie
chciałem powiedzieć , że gdybyśmy mieli mały domek , wracałbym z pracy , a ty czekałabyś w drzwiach
nie , ty byś wracała z pracy , a ja czekał w drzwiach
tak byłoby lepiej
weszlibyśmy do domu opuścili zasłony w oknach , zgasili światło i
jesteś pewna , że twój mąż nie żyje ?
no , tak
słyszę odcień niepewności w tym " tak "
raz przez takie " tak " musiałem skakać z okna
a nie umiem tak skakać jak dawniej
chodzi o to , że zostaniesz tu na zimę , a ja i tak nie mogę się stąd ruszyć weź mnie , póki nie znajdziesz kogoś innego
panie hammer , nie wyjdę za mąż , póki nie wydam córki
raz już to zrobiłaś kocham cię
kocham
nie widzisz , że schnę z tęsknoty za tobą ?
- co z panem ?
- nie jestem dziś sobą
nie wiem , kim jestem
jeden fałszywy ruch i jestem twój
kocham cię
kocham mimo wszystko
- nie kochałbyś mnie , gdybym była biedna
- mógłbym , ale nic bym nie mówił
nie będę tu siedzieć i wysłuchiwać tych obelg
nie odchodź
zostań , a ja pójdę
- nie wiem , co powiedzieć
- powiedz , że będziesz moja albo twoja , albo szczerze tobie oddana
- nie widzisz , że
- niech pan trzyma ręce przy sobie
zróbmy to jeszcze raz
wszystkie trzy
zniż się trochę
tylko pomyśl , dzisiaj , kiedy księżyc wyjdzie zza chmury , ja wyjdę zza ciebie
schadzka przy księżycu
już to widzę : ty i księżyc
włóż krawat , bym was nie pomylił
chciałam zamówić wodę z lodem
tak
dziękuję
- nareszcie
- zamknij drzwi
- masz klucz ? - tak
to jeden z tych
dobrze
nie możemy ryzykować
- jak to ?
- gdy odkryje brak naszyjnika , będą kłopoty
- nie mogą go znaleźć przy nas
- masz rację
trzeba go gdzieś schować
- schować ?
- tylko na jakiś czas - ale gdzie ?
- na pewno nie tutaj
znam odpowiednie miejsce
pusty pień drzewa jakąś milę stąd
może być ?
- tak , ale jak tam trafię ?
- to cocoanut manor
byłaś tam
- nie jestem pewna
- narysuję ci najpierw pójdziesz cocoanut road
tu jest augustine road skręcisz w granada road
wyjdziesz na polanę
to właśnie cocoanut manor tam jest ten pień
jakieś sześć metrów za polaną
tam ukryjesz naszyjnik
na pewno trafisz
zanieś tam naszyjnik
ja muszę wracać do pani potter , inaczej zacznie coś podejrzewać
- bądź ostrożna
cocoanut manor , granada road , sześć metrów za polaną
wszystko idzie jak po maśle
- to ja , książę walii
pamiętasz ? - oczywiście
panie hammer , jak pan śmie wchodzić do mego pokoju ?
jeśli przebywa w nim dwoje ludzi , trzeba dopłacić 50 centów
poszedł ? - kto ?
- ten ktoś
uciekaj
książę , ale mnie wystraszyłeś !
tu jest nie tylko bieżąca woda , ale biegający goście
- to ja , książę walii
pamiętasz ?
- kto tam ?
- to ja , król anglii - mój ojciec !
proszę
- woda z lodem
- postaw tam
dziękuję
dziękuję ?
proszę
połóż tam
coś takiego !
wypraszam sobie
wynoś się
no , już
proszę
co z nim jest ?
panie hammer , co pan robi w moim pokoju ?
niech pan się nie waży zdejmować tu marynarki
proszę stąd natychmiast wyjść
- to była taka gra
- dzwonię na policję
na szczęście już sobie poszedł
nie trzeba
- kim pan jest ?
- spokojnie
to zajmie tylko chwilę
- nie ma tu nikogo
- trzeba wiedzieć , gdzie szukać
- co pani mówiła ?
- to straszne
jak pan skończy , proszę mi dać znać
- wszystko wydaje się być w porządku
- nie jestem tego taka pewna
tak , wiem , co robić
nareszcie sama
chodź , musimy porozmawiać
nie życzę sobie , by ten rudzielec biegał po hallu
musisz go złapać i zamknąć w pokoju
- nie nadążam za nim - co to za jeden ?
- to mój wspólnik , nie mówi
- cichy wspólnik ?
w telegramie pytałeś o działkę
przemyślałem sprawę
mogę ci sprzedać trzy działki nad wodą albo trzy działki pod wodą
dałem za nie 9000 $ tobie sprzedam za 15000 $ , bo cię lubię
- nie kupię
nie mam pieniędzy - co ?
- nie masz pieniędzy ?
- ani centa
- jak chcesz zapłacić za pokój ?
- to twoje zmartwienie
a ty nie spoczniesz w pokoju
przyjechaliśmy tu , by się dorobić
gazety pisały : " forsa leży na ulicy " więc jesteśmy
my też śpimy na ulicy
powiem ci , jak zarobić prawdziwe pieniądze
niedługo organizuję aukcję w cocoanut manor
- wiesz , co to aukcja ?
- u rodziców we włoszech rosła akacja
zapomnij , że pytałem
organizuję aukcję w cocoanut manor
ty wmieszasz się w tłum licytujących
- tylko nie opróżniaj im kieszeni
- znajdę czas na jedno i drugie
może zrezygnujemy z aukcji
jak ktoś powie 100 , ty mówisz 200
ktoś powie 200 , ty 300 - mam podbijać cenę
- właśnie
jeśli nikt nic nie powie , ty zaczniesz
skąd będę wiedział , że nic nie mówią ?
zawiadomią cię
ty durniu , jeśli nic nie powiedzą , na pewno usłyszysz
- a jak nie będę słuchał ?
- to nic im nie mów
jak uda się nam sprzedać te działki , dostaniesz prowizję
- wolałbym pieniądze
- wybór należy do ciebie
będziemy używali planów geodezyjnych
- wiesz , co to są plany geodezyjne ?
- ostrygi
- miałeś obustronne zapalenie płuc ?
- trzymam się jednej strony
- wiesz , co to działka ?
- to dla mnie za dużo
źle mnie zrozumiałeś
mówię o niewielkiej działce trawy
dla kogoś , kto nie bierze , działka to za dużo
wyjaśnię ci to
jedna działka wiele znaczy dla kogoś na głodzie
weźmiesz trochę , chcesz więcej
inni myślą , że wziąłeś za dużo
a wziąłeś tylko jedną
czyli jedna działka to za dużo
przypomnij mi , bym nie wdawał się z tobą w dyskusje
siadaj , wszystko ci wyjaśnię
to jest mapa całego cocoanut
obszar o promieniu jednego kilometra
jest jakaś szansa , że wiesz , co to promień ?
zawartość alkoholu we krwi
żałuję , że zapytałem
teraz będzie już z górki
- szybko kapuję
- chyba kumpli
skup się , einsteinie
to jest kokosowy dwór
nieważne , co myślisz , to jest kokosowy dwór
tu jest kokosowy dwór
tu kokosowe wzgórza
to bagna a tutaj , gdzie rzeka się rozgałęzia , to kokosowe rozstaje
- a gdzie kokosowe wiórki ?
- tam , gdzie drwa rąbią
ale nie przejmuj się , tym zajmą się drwale
to główna droga prowadząca do kokosowego dworu
tam masz być
tutaj zbudujemy szpital okulistyczny
coś miłego dla oka
- nadążasz ?
- tak
tu jest dzielnica mieszkalna
- mieszkają w niej ludzie ?
- nie , zwierzęta
tu jest nabrzeże wzdłuż rzeki biegną wały
dzielnica żydowska ?
udam , że tego nie słyszałem
ale z ciebie aparat
tu jest półwysep i wiadukt łączący go z lądem
- via dukt ?
- ja w porządku
a ty ?
to półwysep , a to wiadukt łączący go z lądem
dlaczego via dukt ?
to nie " dziesięć " pytań do " wiadukt i tyle
ale dlaczego via dukt ?
czemu nie via drut ?
nie wiem
ja też jestem nietutejszy
wiem tylko , że to wiadukt
spróbuj przejść po drucie , a przekonasz się , dlaczego wiadukt
- nigdzie nie idę
- rzeka jest głęboka , stąd wiadukt
- głęboka rzeka
- stąd via dukt
posłuchaj , buraku , przypuśćmy , że jedziesz konno , widzisz wołgę i chcesz przejechać na drugi brzeg
ale nie możesz , bo rzeka jest głęboka
po co ci wołga , skoro masz konia ?
szkoda , że o tym wspomniałem
- wiem tylko , że to wiadukt
- w porządku
rozumiem dlaczego koń , dlaczego drut
ale nie rozumiem , dlaczego via dukt
żartowałem
rano wybudują tam tunel
- teraz jasne ?
- wszystko oprócz via duktu
dobrze
kontynuujmy
pokażę ci cmentarz
na liście oczekujących jest 50 ludzi ale polubiłem cię
- przyjacielu
- zejdziesz przed nimi
- wiedziałem , że mnie lubisz
- załatwię ci etat na stałe
- świetnie
- jak się da , to w pozycji leżącej
- wracając do aukcji , jak ktoś powie 100
- ja mówię 200
super
jak ktoś powie 200 - ja mówię 300
- wspaniale
- wiesz , jak się tam dostać ?
- nie
idź tą wąską ścieżka , aż dojdziesz do tej małej dżungli
- tak
jest tam taka mała polana ogrodzona siatką
- widzisz , taki płot z siatki ?
- płoć z sieci ?
nie naciągniesz mnie na tę dyskusję
chodź ze mną
wiem , mam podbijać cenę
ktoś mówi 100 , 200
jak ktoś powie 100 , ty mówisz 200
jak on 200 , ty 300
jak się uda , dostaniesz wszystko , co już masz
- nic nie mam
- bądź czujny
nic więcej
bądź czujny albo nic nie dostaniesz
będę czujny , choć nie wiem , co to znaczy
wszyscy chętni do nabicia w butelkę , zbliżcie się
drodzy państwo , zanim przejdziemy do głównego punktu wieczoru , którym jest sprzedaż działek za byle co , przyda nam się chwila rozrywki krótka chwila
przedstawiam państwu pannę polly potter , najlepiej płacącego gościa
a właściwie jedynego płacącego gościa hotelu
zaśpiewa dla państwa i dla mnie
małpom na wolności nigdy nie brak radości
nigdy nie dopada ich chandra taka jest prawda
w przeciwieństwie do mieszkańców zoo
małpy na wolności tańczą taniec radości
pośród drzew mango tańczą swoje tango
specjalnie dla miłych gości zatańczą taniec radości
" mała małpka melodię " wygrywa " na jej znak wszyscy dorośli
tańczą taniec radości
" zaprowadzę " was do dżungli " gdzie muzyka dudni
kto na tańce za stary niech bierze przykład z małpy
a potem niech taniec zaczyna oto nowa teoria darwina
" zachęcamy wszystkich gości " by zatańczyli taniec radości
to właśnie floryda , ludziska : śpiewy , tańce i zabawa
po części rozrywkowej będą kanapki
jeśli nikt nie kupi działki , nie będzie kanapek
to floryda , ludziska
słońce przez cały rok
zaczynajmy aukcję , zanim nawiedzi nas tornado
podejdźcie
jesteśmy w cocoanut manor , w jednym z piękniejszych miast florydy
wymaga jeszcze wykończenia , ale co nie wymaga ?
to dzielnica mieszkalna
dosłownie rzut kamieniem od stacji
jak narzucają kamieni , zbudujemy stację
stanie tutaj 800 wspaniałych rezydencji
najwyższy standard
każdy może mieć taki dom , o jakim marzy
można sobie zamówić stiuki
zapłacicie od sztuki
kupujcie teraz , kiedy jest boom
znacie takie powiedzenie : " bum , bum i po ptakach " ?
nie zapomnijcie o gwarancji : mojej gwarancji
jeśli za rok wartość działek się nie podwoi , nie wiem , co zrobicie
na pierwszy ogień idzie działka nr 20 , na rogu alei de sody
wszyscy wiedza , kim był de soda
otóż odkrył wodę
na pewno słyszeliście o wodzie , która nosi jego imię :
sodowa
działka ma 6 m z przodu , 4 m z tyłu i jeszcze coś na boku
cena wywoławcza :
co łaska 200
ten pan daje 200
kto da 300 ? 300
inny pan daje 300
kto da 400 ? 400
licytacja właściwie zakończona
pozostało mi tylko strzelić sobie w łeb
- później się tym zajmę - 500
- kto da 600 ? - 600 sprzedano za 600 dolarów
zapakować i pokropić wyciągiem z sumaka jadowitego
wyszedłem na swoje na tej działce
to spory sukces
jeszcze jeden taki sukces , a sprzedam swoje ciało akademii medycznej
teraz pod młotek idzie działka nr 21
to tamta
tam , gdzie rośnie to drzewo kokosowe
- rozpoczynamy licytację - 200
mleko w tych kokosach jest warte więcej
a co to za mleko
z zadowolonych kokosów
- kto da 300 ?
- 300 - 400 - 400
- 500 - 500
600 , 700 , 800 , a co mi tam
a co ci tam ?
a pomyślałeś o mnie ?
sprzedano panu co mi tam za 800 dolarów
oby popsuły ci się wszystkie zęby
pamiętaj : o zmarłych myślimy życzliwiej
coś zaczęło mi śmierdzieć , gdy spytał : " czemu via dukt "
ale nie wiedziałem co
teraz działka nr 22
- zaczynamy licytację - 100
- sprzedano za 100
- 200 będziesz musiał wcześnie wstawać , by się podnieść z łóżka
- licytujemy działkę nr 23 - 200
po co ci tyle działek ? chcesz być działaczem ?
- kto da 300 ?
- 400
kto da 500 ?
- sprzedano temu panu - 600 - 700
700
sprzedano temu panu - 800 - kto da 900 ?
- czy słyszę 9 ?
- słyszysz 9 , a zaraz usłyszysz 10
jak usłyszę 10 , ty się nasłuchasz
czy słyszę 9 ? niech ten pan , co powiedział 7 , powie 9
niech powie 7 jeszcze raz
niech powie chociaż 6
jak powie 6 , ja powiem 7
jak powie 7 , ja powiem 8
jak powie 8 , ja powiem 9
mogę tak długo
jak zacznę , nic mnie nie powstrzyma podbijam cenę
coraz wyżej
zaraz wylecisz stąd z hukiem
sprzedano panu hiawatha za 800 dolarów
odejdź od drzewa , zanim uschnie
- 50
- sprzedano za 200 !
za późno !
licytacja działki nr 25 , tej , na której stoicie
zdejmijcie buty , żeby jej nie pobrudzić
nie robi wrażenia , ale jest tania jak barszcz
cena wywoławcza :
co łaska
są chętni ?
ktokolwiek
gdzie się podział królik piotruś ?
kto da cokolwiek ?
dalej , ludzie , możecie licytować
to wolny kraj
kto da cokolwiek ?
dorzucę jeszcze roczną prenumeratę młodego technika
jest jakiś chętny na samą prenumeratę ?
staram się zarobić na studia
a na półroczną ? pójdę chociaż do liceum
to może ołówek grafitowy ?
wezmę się na rękę z każdym z tłumu za 5 dolarów
nic tu po mnie , skoro nie chcecie licytować
co jest z wami ?
nie chcecie zarobić ?
spróbuję zlicytować ostatnią działkę , jak się jej nie pozbędę , zwijam interes
działka nr 26 , przebój tej aukcji
niedaleko tego pnia , z widokiem na ocean
jeden z piękniejszych terenów na florydzie słucham - 200
- 300
- kto da 400 ? - 400 kto da więcej
zabierzcie stąd kubusia puchatka on mnie zrujnuje
- kto da 500 ?
- kto da 600 ? - 800
800 oto człowiek z wizją do tego ładna fryzura
kto da 1000 ?
1000
oto człowiek z podwójną wizją i ładniejszą fryzurą
kto da 1100 ?
- 1100
- oto astygmatyk
- kto da 1200 ?
- 1200
kto da 1300 ?
- kto da 1300 ?
- ja 1300 ?
czy słyszę 1300 ?
1200 ?
po raz pierwszy , po raz drugi
sprzedano panu adamsowi za 1200
ładny kawał ziemi , kolego
- bob , udało ci się - zapisz to
- co się stało ?
- protestuję nie mogłem licytować
jak to ?
nikogo nie dyskryminowałem
wszyscy mieli równe szanse
panie hammer , okradziono mnie
co takiego ?
- skradziono mi naszyjnik w pańskim hotelu
- mamo był wart 100000
czy był cenny ?
ten , kto go znajdzie dostanie 1000 dolarów nagrody
ta pani straciła naszyjnik wart 100000
oferuje 1000 $ nagrody dla znalazcy
- 2000
- sprzedano za 2000
- zapisz to
- już idę
ja się tym zajmę
cofnijcie się , wszyscy i bądźcie cicho
- przestań
- cofnąć się , wszyscy
co się stało ?
skrzywdził cię ?
co jest ? nie popychaj
chodź
dobrze
chcesz się bić ?
panie hammer , co mu jest ?
nie wiem , kto to jest
nie ma żadnych dokumentów
o co chodzi ?
mój naszyjnik
wybawco
tak się cieszę
niech cię ucałuję
widziałem cię wczoraj w jej pokoju
ukradłeś naszyjnik , by zdobyć nagrodę ?
przyznaj się
puszczaj
zostawcie go
skąd wiedziałeś , gdzie jest naszyjnik ?
- mogę coś powiedzieć ? - o co chodzi ?
może ten , kto kupił tę działkę , wiedział o naszyjniku
- dlaczego mu tak na niej zależało ?
- po co kupiłeś tę działkę ?
nie twój interes - to desperat
- wcale nie , mamo
jak mężczyzna nie chce mówić , zazwyczaj chodzi o kobietę
- kim ona jest ?
- nie twój interes
nic nie powiem
nic nie powiesz
ten udaje niemowę
tamten mówi , ale nie można go zrozumieć
- czy ktoś chce coś powiedzieć ?
- ja , ale nic nie przychodzi mi do głowy
nic nie chcecie mi powiedzieć , powiecie komu innemu
- chwileczkę
to znaczy - dosyć tego
idziemy
- nie zabierajcie go , proszę
- co ?
nie chciałam , żebyś go ukradł , bob
nie myślałam , że to zrobisz
- czuję się podle
- o czym ty gadasz ?
- bob , o czym ona mówi ?
- polly
- a więc to tak
- to wszystko moja wina
nie sądziłam , że potraktuje to poważnie
nie chciałam , byś go ukradł , tylko , byś mi dał taki sam
chwileczkę
oskarżasz mnie o kradzież naszyjnika pani potter ?
biorę całą winę na siebie
żartowałam , a ty wziąłeś to na poważnie
kiedy mi powiedziałeś , że go wziąłeś , nie mogłam w to uwierzyć
co wziąłem ?
polly , ona oszalała
- dla mnie brzmi to wiarygodnie
- mamo
nie wiedział , co robi
prosiłam go , by go zwrócił
dłużej nie będę tego znosić
cała ta sprawa jest niedorzeczna
to jakiś absurd
naprawdę myślicie , że
zresztą , nie obchodzi mnie , co myślicie
polly , ty wiesz , że ona kłamie
to był niewinny flirt , ale on stracił głowę
- wiesz , że ona kłamie ?
- oczywiście
nie wierzę w jej bajeczkę - polly
- nie wierzę i już
panie adams , proszę przestać spotykać się z moją córką
- bob , idę z tobą
- nigdzie nie pójdziesz
tak , polly
zostań z matką
to nie potrwa długo
- to jakiś absurd
- jest pan gotów ?
- tak
- przykro mi , bob
nie udawaj
wyciągnę od niego prawdę w pół godziny
idziemy - wracaj
- licytacja działki nr 27
tak słabo mi poszło z tamtymi , że do każdej sprzedanej działki dołączę paczkę herbaty
tylko w jeden sposób można zmyć tę hańbę
ludzie muszą zapomnieć , że kiedykolwiek znałaś tego człowieka
ależ mamo !
co ty mówisz ?
robiłaś , co chciałaś i takie są efekty
teraz zrobisz to , co ci każę
- panie yates ?
- słucham ?
moja córka przemyślała swoją odpowiedź mamo
jeszcze dziś zostaną ogłoszone wasze zaręczyny
wspaniale , polly
- wydam kolację w hotelu
- kolację ?
- za 30 czy 40 centów ?
- zapraszam wszystkich
czyli za 50 z deserem z okazji zaręczyn mojej córki z harveyem yatesem
będę ostatni , który wam pogratuluje
życzę okropnego ślubu
- moje gratulacje , yates
- idziesz , polly ?
- za chwilę
- ty idź
- co się stało , kochanie ?
nic
proszę cię , idź
dobrze
będę na ciebie czekał
masz klucz ?
dobra robota
zaczekaj
ja mam piłę
ty musisz coś zdobyć
wypuścimy boba
- cześć
- cześć
co tu robicie ?
- wpuścili was ?
- przyszliśmy cię stąd wydostać
- trzeba się uwinąć
- niepotrzebnie się fatygowaliście
- lepiej tu zostanę
- nie możesz
- polly chce się z tobą widzieć
- polly ?
dziś są jej zaręczyny zaręczyny ?
wychodzi za mąż
pani potter wydaje przyjęcie zaręczynowe
- dla kogo ?
- dla polly
zaręczył się z nią
- będą tam wszyscy ty też
- polly wychodzi za yatesa ?
- tak
- wypuśćcie mnie stąd , szybko
spokojna głowa
hej , " paisan , " pospiesz się
wydostaniemy cię stąd
dzięki nie jestem głodny
nie mam teraz do tego głowy
- szybciej
wypuśćcie mnie stąd
co jest ?
co robisz ?
- szybciej
rozwal zamek
co jest z tobą ?
chodź
przestańcie !
to nie pora na bijatykę
pospieszcie się
szybciej
szybciej , bob
naprawdę ?
zajmę się tym
boy
doniesiono mi , że w pokoju 420 grają w pokera
- idź , zapytaj , czy mogę się przyłączyć
już idę
w porządku , bob
droga wolna
nikogo nie ma oto on
przyprowadziliśmy go
- witam
wyszedłeś warunkowo ?
- ci panowie pomogli mi wyjść
jestem wielce zobowiązany
powiedzieli mi , że to był pański pomysł
- nie wiem , jak ci dziękować
- może kiedyś zrobisz dla mnie to samo
- no to , " arrivederci " do widzenia
- nie wiem , jak ci dziękować
to już poligamia
proszę mi wierzyć , więzienie to nic przyjemnego
to nie miejsce dla młodych
nie można się rozwijać
a tak na poważnie , wie pan , że ta historyjka penelopy to kłamstwo
nie przejmuj się
dziś jesteś tam , jutro tu
ale wie pan , że to kłamstwo
jak mam tego dowieść ?
co to jest ?
" policja poszukuje rudego niemowy "
co się dzieje ?
wszystko ci leci
grejpfrut
mam nadzieję , że bieliznę wciąż mam na sobie
wiesz
daj to
czuję się goły
- bob
- słucham ?
idź na górę i policz pokoje
mam wrażenie , że brakuje trzeciego piętra
położę to tutaj , dopóki nie będę gotów iść na górę
chwileczkę
" blackstone hotel , chicago "
" statler hotel , cleveland " ?
to moje
coś takiego
nigdy nie widziałem , by ktoś nosił tyle papierów
" granada road
cocoanut road "
" granada road , cocoanut "
" granada "
jeszcze dwa razy i jest twoja
oddaj to
przywiązuję się do swoich rzeczy
" granada road "
nic nie mów
wyjmie ci słowa z ust
" granada "
" granada road
cocoanut road
pusty pień
naszyjnik "
- skąd to masz ?
- na pewno ci powie
gdzie to znalazłeś ?
panie hammer , ten , kto to narysował , wie coś o kradzieży
nastanie
" piękny dzień "
" kiedy ziści się mój sen
uśmiech na mojej twarzy zagości
kiedy mój sen
" się " ziści "
hiszpański pałac
" który wzniosę
" stanie się " dla nas " miłosnym gniazdkiem
zamieszkamy w nim ty i ja
" kiedy ziści się mój plan
penelope , moja droga , miło , że przyszłaś
dziękuję , pani potter
czyż to nie wspaniałe ?
- szczęściarz z ciebie , harvey
- owszem
- jestem pewna , że przyjęcie się uda
- mam nadzieję
- witaj , penelope
- witam
- nie wiedziałam , że tu będziesz
- dobry wieczór
- dobry wieczór
- czy pan hammer przyjdzie ?
- niedługo powinien się zjawić
panie hammer , wspaniały kostium
ten kostium został potępiony przez " panią domu "
- ładny zestaw kolorów
- to nie zestaw , tylko zastaw
" senor " chico joseph maria de accunia , hrabia de elsinore
na torze 25
słuchaj , hrabio , jak tylko goście wyjdą , chciałbym , abyś wyniósł prochy
jego ekscelencja , ambasador san rafaelo
" senor " de harpeno
przestań
powiało starą irlandią
przed oczami mam moją matkę , jak idzie drogą
i starego
shimmy szuja
teraz idzie szuja
- cieszę się , że pan przyszedł
- dziękuję na takim przyjęciu musi być stróż prawa
a kobieta taka jak pani potrzebuje ochrony , jestem tu , by ją pani zapewnić
kręcą się tu podejrzane typy będę miał na nich oko
- co mu tam dałeś ?
- nic
daj mi to
kto mi zabrał koszulę ?
co się stało z moją koszulą ?
oddajcie mi koszulę
- zginęła ci koszula
- tak
- możesz ją opisać ?
- co to jest ?
patrz
ten krzyżyk oznacza miejsce , gdzie ostatni raz widziano koszulę
- przestańcie
tak jak myślałem
to wasza sprawka nie chcecie , bym znalazł swoją koszulę
to kłamstwo , fiucie
fiu , fiu !
- oddajcie mi koszulę - on chce swoją koszulę
- oddajcie mi koszulę - on chce koszulę
" on chce swoją koszulę
" - oddajcie mi moją koszulę " - on chce swoją koszulę
" - oddajcie mi moją koszulę " - on chce swoją koszulę
" oddajcie mi moją koszulę " bez niej będę " nieszczęśliwy "
" on chce swoją koszulę " , " " on chce swoją koszulę
" bez niej będzie nieszczęśliwy "
" - oddajcie mi moją koszulę " - on chce swoją koszulę
" bez niej będzie nieszczęśliwy "
" on chce swoją koszulę " , " " on chce swoją koszulę
" nie zazna szczęścia , póki jej nie odzyska "
" znalazła się " , znalazła się " ! " " odzyskałem swoją koszulę " bogu niech będą dzięki "
" odzyskałem swoją koszulę
" nie macie pojęcia , jak bardzo cierpiałem "
myślałem , że na zawsze ją straciłem
- dostałem ją od mego brata berta - od brata berta
dlatego jest mi tak bliska
" - to piękna koszula " - moja koszula
wspaniała koszula
" skoro znalazła się " moja koszula "
żegnam !
moi drodzy , skoro znalazła się koszula hennessy'ego , poszukajcie teraz mojego guzika od kołnierzyka
rozmiar 34 i pół
panie , panowie , zajmijcie miejsca przy stole przed kolacją odbędzie się część rozrywkowa
jedzenie !
idziemy
może wymkniemy się stąd na szybki numerek ?
co ?
szanowni państwo , pan hammer będzie pełnił funkcję mistrza ceremonii
panie hammer
drodzy państwo
daję 200 $ !
w imieniu klubu rotary z minneapolis , chciałbym skorzystać z okazji i powitać was w waukegan
to znaczy , doceniając moją pracę na kolei , podarowaliście mi te krawaty
przypomina mi się historia pewnego irlandczyka
jest przezabawna szkoda , że jej nie pamiętam
" gdy w cichą noc słychać jak drżą liście " wzdycham pośród drzew nad szemrzącym strumykiem
" który płynie nieubłaganie , szemrząc i "
no i o jednego mniej
jeden taki liczy się za trzech
na czym to skończyłem ?
a tak , na krześle
ceny bydła były na poziomie 1525 na otwarciu
jednoroczniaki i cielęcina trzymały się mocno
jajka zareagowały nerwowo , zaczęły spadać
matka z ojcem omówili wszystko i przeprowadzili się do nowego jorku
wynajęli domek w bronksie
tam właśnie przyszedł na świat abraham lincoln , czym zaskoczył mego ojca
taki był początek autostrady lincolna
drodzy przyjaciele , jako że świętujemy dziś zaręczyny panny polly , sądzę , że kilka słów z ust jej matki będzie odrażające
z wielką przyjemnością przedstawiam wam dobrze zakonserwowaną i trochę ukiszona , panią potter
brawa dla tej małej
przemówienie
drodzy przyjaciele , gdybym tylko potrafiła opowiedzieć , jak wszystko widzę dziś w różowych kolorach
gdy patrzę na wasze twarze , widzę na nich radość
cały świat i wszystko na nim jest skąpane w delikatnej , błyszczącej mgiełce
stara się ubzdryngoliła
życzę wam miłego wieczoru
ja sama jestem smutna
dłużej już nie mogę
dam ci spokój
a teraz , przyjaciele , z wielką przyjemnością przedstawiam pana młodego , harveya yatesa
dobry wieczór , radiosłuchacze
wracamy do studia
zaraz usłyszycie prezentera
drodzy przyjaciele
- doprawdy nie wiem , co powiedzieć
- to się zamknij
świetna propozycja
czuję się zaszczycony , ale słaby ze mnie mówca
tym niemniej , panie hammer , miło , że udzielił mi pan głosu
musi pan kiedyś do mnie wpaść
- chciałem
- zobaczy pan moje klomby
- chciałem powiedzieć
- pokażę panu moje bratki
i te krótkie , i te długie
- chciałem powiedzieć
jak już mówiłem
zdaje się , że alkohol leje się tam ciurkiem
nie chcę zabierać więcej czasu
chciałem wam podziękować i , jak już mówiłem ,
- nie miałem zamiaru przemawiać
- ale jednak przemówiłeś
a teraz , przyjaciele
co z nim ?
ma gazy
panie hammer , niech pan coś zrobi
nie muszę
oni robią za trzech
a teraz , mili państwo , pierwszy numer , który na dziś zaplanowaliśmy będzie to początek i koniec
będzie muzyka
pierwsze na liście jest solo pikolo , które sobie darujemy
drugi na liście jest " senor " pastrani , litewski pianista
" senor " zagra numer zatytułowany : " kawa , kanapka i ty " pochodzący z opery " aida "
" senor , " zaprowadzę pana na podium
" senor " pastrani , jaki jest pierwszy numer ?
numer jeden
a teraz , drodzy przyjaciele , przedstawiam wam czarującą damę
- z przodu
- siadaj
damę , która zostanie panią yates po moim trupie
wiem , że wszyscy mi dobrze życzycie doceniam to
to najszczęśliwszy moment w moim życiu
patrz , co tu mam
to prezent zaręczynowy od pana yatesa
napisał go przed chwilą wczoraj napisał jeszcze jeden , zanim skradziono naszyjnik
oba są napisane jego charakterem pisma
przeczytam go wam
rysunek pokazuje , jak znaleźć pusty pień w cocoanut manor niżej jest napisane :
" pusty pień , naszyjnik " - nie wierzę
- sama zobacz
- yates zniknął
- zniknął ?
a rano dałem mu czek na 1000 dolarów
dobrze , że to był mój czek
panie hammer , przyszedł jakiś pan z czarnymi wąsami
powiedz mu , że mam już wąsy
powiedziałem , że zaraz pan przyjdzie
nazywa się john w berryman
zaakceptował mój plan zabudowy cocoanut manor
- moje gratulacje , stary
- dziękuję
pyta również , czy znajdzie się miejsce dla 400 gości na ten weekend
- 400 gości ?
- 400
co się dzieje ?
mamo , przyznaj , że się myliłaś
panie adams , proszę mi wybaczyć
proszę , pani potter
drodzy państwo , zapraszam wszystkich na ślub mojej córki
ślub odbędzie się zgodnie z planem
zaszła tylko jedna drobna zmiana
moja córka wyjdzie za pan roberta adamsa
hurra !
nastanie
" piękny dzień "
" kiedy ziści się " mój sen "
uśmiech na mej twarzy zagości
" kiedy mój sen się " ziści "
hiszpański pałac
" który wzniosę
" stanie się " dla nas " miłosnym gniazdkiem
zamieszkamy w nim , ty i ja
" kiedy ziści się mój plan
koniec
w niedzielę miał premierę w lutego 1930 roku w berlinie
to wtedy 2014 metrów oryginalnego negatywu został utracony nie pełną kopię istnieje
ta wersja pochodzi z kopii z holandii film museum języku niderlandzkim jest krótszy , 1615 m sceny brakujące został ponownie wstawić
kopie ze szwajcarskiej cinemateque , royal belgijski cinemateque i włoski fondazione cineteca dostarczone brakujące sceny
nowy niemiecki intertitles na podstawie cenzury rekordy zostały wykonane
film jest teraz 1839 metrów
studio filmowe 1929 prezentuje jego pierwszego eksperymentu
ludzie
w niedzielę filmu bez aktorów
eugen schüfftan
reżyseria : robert siodmak , edgar g ulmer
te pięć osób pojawił się przed kamerą po raz pierwszy w życiu
dziś wszyscy są z powrotem w ich własnych miejsc pracy pobrane z wwwopensubtitlesorg
erwin dyski splettstösser taxi 1a 10088
w zeszłym miesiącu , brigitte borchert sprzedał 150 egzemplarzy tego zapisu > w małej cukierni
wolfgang von waltershausen urzędnik , rolnik , antykwariusz , gigolo , wino przedsiębiorcy
christl ehlers zużywa się jej buty jazdy po role w filmie dodatkowych
annie schreyer , model
pewnej soboty
" żenujące , będąc wstał , nie ?
czy jest sprawiedliwe lub ciemne ? "
" ani !
nikt nie stoi mi się ! "
" annie przez telefon
czy chcesz iść do kina dziś wieczorem ? "
" dlaczego ona jest co takie zamieszanie ?
greta garbo jest do wtorku ! "
" no , co będzie jutro ? "
" dobrze , jutro niedzielę ! "
" gotowe
na dziesięć
nikolassee "
" pozostaw po brzegi w dół lub "
" if i were you , chciałbym zrobić trochę scenie ! "
niedziela
przyjdź na 10 do nikolassee
" moje najlepszy przyjaciel "
" ty dalej
muszę zatelefonować "
" nie można sprawdzić , czy annie nadal istnieje , proszę ? " </ p
> " jak to ?
ona jest jeszcze w łóżku ! "
" uśmiech proszę "
" thank you "
" gdzie są innych ? "
" prawie zgubił "
" chodźmy , dzieci przejdźmy "
" dzieci , ktoś może pożyczyć mi znak ? "
" wolf , jak o kolejnych niedziela ? "
" chcieliśmy jednak , aby przejść do mecz w najbliższą niedzielę "
" ja tylko się ubrać
mamy datę "
następnie w poniedziałek
powrót do pracy
powrót do życia codziennego
w tym tygodniu ponownie
cztery miliony osób czeka na dalej niedziela
witam państwa !
w imieniu pana caria laemmie'a chciałem państwu przekazać życziiwą przestrogę
za chwiię zagłębimy się w opowieści o frankensteinie , naukowcu , który stworzył człowieka na swoje podobieństwo , nie iicząc się z woią boga
to jedna z najdziwniejszych historii
mówi o tajemnicy stworzenia : o życiu i śmierci
myśię , że fiim was wzruszy
może wami wstrząśnie
a może nawet was przerazi
jest to fiim dia widzów o siinych nerwach , więc jeśii się boicie
ostrzegałem was
schowaj się , głupcze
szybko
chodżmy
pośpiesz się
księżyc wschodzi
nie mamy czasu do stracenia
ostrożnie !
mamy go
tyiko śpi
czeka na nowe życie
jesteśmy na miejscu
patrz , wciąż wisi
przetnij sznur
- nie
- nie bój się
nie zje cię
trzymaj nóż
uwaga
nóż
skaczę
w porządku ?
ma złamany kark
na nic nam jego mózg
musimy szukać innego
